package cr.nio;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Control total: con el permiso de accesibilidad Beto puede ir atrás, al inicio,
 * cerrar todas las apps y tocar "Enviar" en WhatsApp por vos.
 */
public class BetoAccess extends AccessibilityService {

    public static volatile BetoAccess instance;

    private final Handler h = new Handler(Looper.getMainLooper());
    private long sendUntil = 0;          // hasta cuándo esperar para tocar "Enviar" en WhatsApp
    private Runnable onSent = null;

    public static boolean on() { return instance != null; }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onInterrupt() { }

    // ---------- acciones ----------

    public boolean back() { return performGlobalAction(GLOBAL_ACTION_BACK); }

    public boolean home() { return performGlobalAction(GLOBAL_ACTION_HOME); }

    public boolean recents() { return performGlobalAction(GLOBAL_ACTION_RECENTS); }

    public boolean notifications() { return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS); }

    public boolean screenshot() {
        return Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
    }

    public boolean lock() {
        return Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
    }

    /** Abre las apps recientes y toca el botón de "cerrar todo". */
    public void closeAll(final Runnable done) {
        recents();
        h.postDelayed(() -> {
            boolean ok = clickByWords(new String[]{"cerrar todo", "borrar todo", "eliminar todo", "limpiar todo",
                    "clear all", "close all", "limpiar", "borrar"});
            if (!ok) {
                // en algunos Xiaomi el botón solo tiene ícono: probamos por su id
                ok = clickById(new String[]{"com.miui.home:id/clearAnimView", "com.android.systemui:id/clear_all",
                        "com.miui.home:id/clear_all", "com.android.launcher3:id/clear_all"});
            }
            final boolean fine = ok;
            h.postDelayed(() -> {
                if (!fine) home();
                if (done != null) done.run();
            }, 600);
        }, 900);
    }

    /** Después de abrir WhatsApp con el mensaje escrito, toca "Enviar" solito. */
    public void sendWhatsAppSoon(Runnable sent) {
        sendUntil = System.currentTimeMillis() + 12000;
        onSent = sent;
        h.postDelayed(this::trySend, 1500);
        h.postDelayed(this::trySend, 3000);
        h.postDelayed(this::trySend, 5000);
    }

    private void trySend() {
        if (System.currentTimeMillis() > sendUntil) return;
        boolean ok = clickById(new String[]{"com.whatsapp:id/send", "com.whatsapp.w4b:id/send"});
        if (!ok) ok = clickByWords(new String[]{"enviar", "send"});
        if (ok) {
            sendUntil = 0;
            Runnable r = onSent;
            onSent = null;
            if (r != null) h.post(r);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (sendUntil > 0 && System.currentTimeMillis() < sendUntil && e != null && e.getPackageName() != null) {
            String pkg = e.getPackageName().toString();
            if (pkg.startsWith("com.whatsapp")) trySend();
        }
    }


    // ---------- llamadas ----------

    /** Cuelga la llamada (botón del audífono o el botón rojo de la pantalla). */
    public boolean endCall() {
        boolean ok = false;
        if (Build.VERSION.SDK_INT >= 31) ok = performGlobalAction(GLOBAL_ACTION_KEYCODE_HEADSETHOOK);
        if (!ok) ok = clickByWords(new String[]{"finalizar llamada", "terminar llamada", "colgar", "finalizar", "end call"});
        if (!ok) ok = clickById(new String[]{"com.android.dialer:id/incall_end_call", "com.google.android.dialer:id/incall_end_call",
                "com.android.incallui:id/endButton", "com.android.incallui:id/end_call"});
        return ok;
    }

    // ---------- toques en la pantalla ----------

    private void tapAt(float x, float y, long delay) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, delay, 40)).build();
        try { dispatchGesture(g, null, null); } catch (Exception ignored) { }
    }

    private void doubleTapAt(float x, float y) {
        Path p1 = new Path();
        p1.moveTo(x, y);
        Path p2 = new Path();
        p2.moveTo(x, y);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p1, 0, 40))
                .addStroke(new GestureDescription.StrokeDescription(p2, 130, 40)).build();
        try { dispatchGesture(g, null, null); } catch (Exception ignored) { }
    }

    /** YouTube: doble toque a la derecha adelanta 10 segundos, a la izquierda devuelve 10. */
    public void seek(boolean forward, int times) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float w = dm.widthPixels, hgt = dm.heightPixels;
        float y = w > hgt ? hgt * 0.5f : hgt * 0.17f;
        float x = forward ? w * 0.82f : w * 0.18f;
        for (int i = 0; i < times; i++) {
            h.postDelayed(() -> doubleTapAt(x, y), i * 900L);
        }
    }

    /** Toca el primer video de los resultados de YouTube. */
    public void playFirstYouTube() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            // busca un elemento que diga "minutos"/"vistas" (las tarjetas de video) y lo toca
            for (String w : new String[]{"minutos", "minutes", "vistas", "views"}) {
                List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(w);
                if (list != null) for (AccessibilityNodeInfo n : list) if (click(n)) return;
            }
        }
        tapAt(dm.widthPixels * 0.5f, dm.heightPixels * 0.30f, 0);
    }

    /** Toca el primer resultado que coincida con lo buscado. */
    public void openFirstResult(String q) {
        if (!clickByWords(new String[]{q})) {
            String[] words = q.split(" ");
            if (words.length > 0) clickByWords(new String[]{words[0]});
        }
    }

    /** Spotify: abre la playlist buscada y toca "Descargar". */
    public void spotifyDownload(String q, Consumer<String> done) {
        h.postDelayed(() -> {
            boolean opened = clickByWords(new String[]{"Playlists", "Listas"});
            h.postDelayed(() -> {
                openFirstResult(q);
                h.postDelayed(() -> {
                    boolean ok = clickByWords(new String[]{"descargar", "download", "Descargar"});
                    done.accept(ok ? "Listo, la playlist " + q + " se está descargando en Spotify."
                            : "Te abrí la playlist " + q + ", pero no encontré el botón de descargar. Ese botón sale solo con Spotify Premium.");
                }, 3500);
            }, opened ? 2500 : 500);
        }, 3500);
    }

    // ---------- leer la pantalla ----------

    public String screenText() {
        StringBuilder sb = new StringBuilder();
        walk(getRootInActiveWindow(), sb, 0);
        String s = sb.toString();
        return s.length() > 7000 ? s.substring(0, 7000) : s;
    }

    private void walk(AccessibilityNodeInfo n, StringBuilder sb, int depth) {
        if (n == null || depth > 45 || sb.length() > 7000) return;
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        if (t != null && t.length() > 0) sb.append(t).append('\n');
        else if (d != null && d.length() > 0) sb.append(d).append('\n');
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), sb, depth + 1);
    }

    /** Busca un enlace en la pantalla (por ejemplo, la barra de direcciones del navegador). */
    public String findUrlOnScreen() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            for (String id : new String[]{"com.android.chrome:id/url_bar", "org.mozilla.firefox:id/mozac_browser_toolbar_url_view",
                    "com.sec.android.app.sbrowser:id/location_bar_edit_text", "com.mi.globalbrowser:id/url"}) {
                List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByViewId(id);
                if (l != null && !l.isEmpty() && l.get(0).getText() != null) return l.get(0).getText().toString();
            }
        }
        Matcher m = Pattern.compile("(https?://\\S+|[\\w.-]+\\.(com|net|org|cr|io|pdf)[/\\S]*)").matcher(screenText());
        return m.find() ? m.group(1) : null;
    }

    private static final String[] PAY = {"pagar", "realizar pedido", "confirmar pedido", "hacer pedido", "comprar ahora",
            "place order", "pay", "checkout", "confirmar compra", "finalizar compra"};

    /** Toca un botón por su texto. 1 = listo, 0 = no lo encontró, -1 = es de pagar (no lo toca). */
    public int clickText(String q) {
        if (q == null || q.isEmpty()) return 0;
        String n = Brain.norm(q);
        for (String p : PAY) if (n.contains(p)) return -1;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return 0;
        List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(q);
        if (list != null) {
            for (AccessibilityNodeInfo node : list) {
                CharSequence t = node.getText() != null ? node.getText() : node.getContentDescription();
                if (t != null) {
                    String nt = Brain.norm(t.toString());
                    for (String p : PAY) if (nt.contains(p)) return -1;
                }
                if (click(node)) return 1;
            }
        }
        return 0;
    }

    // ---------- WhatsApp: grupos y chats por nombre ----------

    private boolean setText(AccessibilityNodeInfo n, String text) {
        if (n == null) return false;
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
    }

    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 40) return null;
        if (n.isEditable()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findEditable(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    /** Abre WhatsApp, busca el chat o grupo por nombre, escribe el mensaje y lo envía. */
    public void sendToChat(String name, String msg, Consumer<Boolean> done) {
        Intent i = getPackageManager().getLaunchIntentForPackage("com.whatsapp");
        if (i == null) i = getPackageManager().getLaunchIntentForPackage("com.whatsapp.w4b");
        if (i == null) { done.accept(false); return; }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
        h.postDelayed(() -> {
            // si quedó abierto un chat, vuelve a la lista
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null && !root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/entry").isEmpty()) back();
            h.postDelayed(() -> {
                boolean s1 = clickById(new String[]{"com.whatsapp:id/menuitem_search", "com.whatsapp:id/my_search_bar",
                        "com.whatsapp:id/search_bar", "com.whatsapp:id/search_holder"});
                if (!s1) s1 = clickByWords(new String[]{"Buscar", "Search", "Preguntar a Meta AI o buscar"});
                h.postDelayed(() -> {
                    AccessibilityNodeInfo r2 = getRootInActiveWindow();
                    AccessibilityNodeInfo box = r2 == null ? null : findEditable(r2, 0);
                    if (!setText(box, name)) { done.accept(false); return; }
                    h.postDelayed(() -> {
                        AccessibilityNodeInfo r3 = getRootInActiveWindow();
                        boolean opened = false;
                        if (r3 != null) {
                            List<AccessibilityNodeInfo> hits = r3.findAccessibilityNodeInfosByText(name);
                            if (hits != null) {
                                for (AccessibilityNodeInfo n : hits) {
                                    if (n.isEditable()) continue;
                                    if (click(n)) { opened = true; break; }
                                }
                            }
                        }
                        if (!opened) { done.accept(false); return; }
                        h.postDelayed(() -> {
                            AccessibilityNodeInfo r4 = getRootInActiveWindow();
                            AccessibilityNodeInfo entry = null;
                            if (r4 != null) {
                                List<AccessibilityNodeInfo> e = r4.findAccessibilityNodeInfosByViewId("com.whatsapp:id/entry");
                                entry = (e != null && !e.isEmpty()) ? e.get(0) : findEditable(r4, 0);
                            }
                            if (!setText(entry, msg)) { done.accept(false); return; }
                            h.postDelayed(() -> {
                                boolean sent = clickById(new String[]{"com.whatsapp:id/send", "com.whatsapp.w4b:id/send"});
                                if (!sent) sent = clickByWords(new String[]{"Enviar", "Send"});
                                done.accept(sent);
                            }, 700);
                        }, 2200);
                    }, 2000);
                }, 1300);
            }, 1000);
        }, 2500);
    }


    // ---------- cámara, Bluetooth y Wi-Fi ----------

    private AccessibilityNodeInfo findCheckable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 40) return null;
        if (n.isCheckable() && n.isEnabled()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findCheckable(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    /** Prende o apaga el primer interruptor de la pantalla (el de Bluetooth o Wi-Fi en Ajustes). */
    private boolean setMainSwitch(boolean on) {
        AccessibilityNodeInfo sw = findCheckable(getRootInActiveWindow(), 0);
        if (sw == null) return false;
        if (sw.isChecked() == on) return true;
        return click(sw) || sw.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    /** Abre la cámara y toca el botón de tomar la foto. */
    public void takePhoto(boolean front, Consumer<Boolean> done) {
        Intent i = new Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (front) {
            i.putExtra("android.intent.extras.CAMERA_FACING", 1);
            i.putExtra("android.intent.extras.LENS_FACING_FRONT", 1);
            i.putExtra("android.intent.extra.USE_FRONT_CAMERA", true);
        }
        try { startActivity(i); } catch (Exception e) { done.accept(false); return; }
        h.postDelayed(() -> {
            boolean ok = clickByWords(new String[]{"obturador", "shutter", "tomar foto", "take photo", "capturar", "disparador"});
            if (!ok) ok = clickById(new String[]{"com.android.camera:id/shutter_button", "com.google.android.GoogleCamera:id/shutter_button",
                    "com.sec.android.app.camera:id/shutter_button"});
            if (!ok) {
                DisplayMetrics dm = getResources().getDisplayMetrics();
                tapAt(dm.widthPixels * 0.5f, dm.heightPixels * 0.87f, 0);
                ok = true;
            }
            done.accept(ok);
        }, 3000);
    }

    /** Bluetooth: lo prende o apaga y, si le dices un aparato, se conecta. */
    public void bluetooth(boolean on, String device, Consumer<String> done) {
        Intent i = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        h.postDelayed(() -> {
            boolean sw = setMainSwitch(on);
            if (!on) { done.accept(sw ? "Listo, apagué el Bluetooth." : "Te abrí el Bluetooth, apágalo con el interruptor."); return; }
            if (device == null || device.isEmpty()) {
                done.accept(sw ? "Listo, Bluetooth encendido." : "Te abrí el Bluetooth, préndelo con el interruptor.");
                return;
            }
            h.postDelayed(() -> {
                boolean found = clickByWords(new String[]{device});
                if (!found) { done.accept("Prendí el Bluetooth, pero no veo " + device + ". Revisa que esté encendido y cerca."); return; }
                h.postDelayed(() -> {
                    clickByWords(new String[]{"vincular", "emparejar", "pair", "conectar", "connect"});
                    done.accept("Conectando con " + device + ".");
                }, 2500);
            }, 3500);
        }, 2000);
    }

    /** Wi-Fi: lo prende o apaga; si le dices una red, la toca. Avisa si pide contraseña. */
    public void wifi(boolean on, String network, Consumer<String> done) {
        Intent i = new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        h.postDelayed(() -> {
            boolean sw = setMainSwitch(on);
            if (!on) { done.accept(sw ? "Listo, apagué el Wi-Fi." : "Te abrí el Wi-Fi, apágalo con el interruptor."); return; }
            if (network == null || network.isEmpty()) {
                done.accept(sw ? "Listo, Wi-Fi encendido." : "Te abrí el Wi-Fi, préndelo con el interruptor.");
                return;
            }
            h.postDelayed(() -> {
                boolean found = clickByWords(new String[]{network});
                if (!found) { done.accept("No veo la red " + network + ". Revisa el nombre o acércate al módem."); return; }
                h.postDelayed(() -> {
                    AccessibilityNodeInfo box = findEditable(getRootInActiveWindow(), 0);
                    if (box != null && box.isPassword()) done.accept("PASSWORD");
                    else if (box != null) done.accept("PASSWORD");
                    else done.accept("Conectando a " + network + ".");
                }, 2500);
            }, 3500);
        }, 2000);
    }

    /** Escribe la contraseña que dictaste y toca "Conectar". */
    public boolean typePassword(String pwd) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo box = findEditable(root, 0);
        if (!setText(box, pwd)) return false;
        h.postDelayed(() -> {
            if (!clickByWords(new String[]{"conectar", "connect", "aceptar", "ok"})) {
                clickById(new String[]{"android:id/button1", "com.android.settings:id/button1"});
            }
        }, 700);
        return true;
    }


    // ---------- Google Home ----------

    private static final String HOME_PKG = "com.google.android.apps.chromecast.app";

    private void subtreeText(AccessibilityNodeInfo n, StringBuilder sb, int depth) {
        if (n == null || depth > 8) return;
        if (n.getText() != null) sb.append(n.getText()).append(' ');
        if (n.getContentDescription() != null) sb.append(n.getContentDescription()).append(' ');
        if (Build.VERSION.SDK_INT >= 30 && n.getStateDescription() != null) sb.append(n.getStateDescription()).append(' ');
        if (n.isCheckable()) sb.append(n.isChecked() ? " encendido " : " apagado ");
        for (int i = 0; i < n.getChildCount(); i++) subtreeText(n.getChild(i), sb, depth + 1);
    }

    /** 1 = encendido, 0 = apagado, -1 = no se sabe. */
    private int stateOf(AccessibilityNodeInfo tile) {
        StringBuilder sb = new StringBuilder();
        subtreeText(tile, sb, 0);
        String t = " " + Brain.norm(sb.toString()) + " ";
        if (t.contains("apagad") || t.contains(" off ") || t.contains("desactivad")) return 0;
        if (t.contains("encendid") || t.contains("prendid") || t.contains(" on ") || t.contains("activad") || t.contains("%")) return 1;
        return -1;
    }

    private AccessibilityNodeInfo clickableParent(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 6 && cur != null; i++) {
            if (cur.isClickable()) return cur;
            cur = cur.getParent();
        }
        return null;
    }

    private void openHome(Runnable then) {
        Intent i = getPackageManager().getLaunchIntentForPackage(HOME_PKG);
        if (i == null) { then.run(); return; }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        h.postDelayed(() -> {
            clickByWords(new String[]{"Dispositivos", "Devices"});
            h.postDelayed(then, 2200);
        }, 3200);
    }

    /** Prende o apaga un aparato de Google Home por su nombre (por ejemplo "sala"). */
    public void homeDevice(String[] names, boolean on, Consumer<String> done) {
        if (getPackageManager().getLaunchIntentForPackage(HOME_PKG) == null) {
            done.accept("No encontré la app Google Home en el teléfono.");
            return;
        }
        openHome(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null) { done.accept("No pude ver la app Home."); return; }
            for (String name : names) {
                if (name == null || name.trim().isEmpty()) continue;
                List<AccessibilityNodeInfo> hits = root.findAccessibilityNodeInfosByText(name.trim());
                if (hits == null) continue;
                for (AccessibilityNodeInfo n : hits) {
                    AccessibilityNodeInfo tile = clickableParent(n);
                    if (tile == null) continue;
                    int st = stateOf(tile);
                    if (st == (on ? 1 : 0)) { done.accept((on ? "Ya estaba encendido: " : "Ya estaba apagado: ") + name + "."); return; }
                    tile.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    done.accept((on ? "Listo, encendí " : "Listo, apagué ") + name + ".");
                    return;
                }
            }
            done.accept("No encontré " + names[0] + " en Google Home. Dime el nombre como sale en la app.");
        });
    }

    /** Prende o apaga todas las luces que salen en Google Home. */
    public void homeAllLights(boolean on, Consumer<String> done) {
        if (getPackageManager().getLaunchIntentForPackage(HOME_PKG) == null) {
            done.accept("No encontré la app Google Home en el teléfono.");
            return;
        }
        openHome(() -> {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            List<AccessibilityNodeInfo> tiles = new java.util.ArrayList<>();
            collectTiles(root, tiles, 0);
            int count = 0;
            for (AccessibilityNodeInfo tile : tiles) {
                StringBuilder sb = new StringBuilder();
                subtreeText(tile, sb, 0);
                String t = Brain.norm(sb.toString());
                boolean light = t.contains("luz") || t.contains("luces") || t.contains("light") || t.contains("lampara")
                        || t.contains("bombillo") || t.contains("foco") || t.contains("bulb");
                if (!light) continue;
                int st = stateOf(tile);
                if (st == (on ? 0 : 1)) {
                    tile.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    count++;
                }
            }
            if (count == 0) done.accept(on ? "No vi luces apagadas en Google Home." : "No vi luces encendidas en Google Home.");
            else done.accept((on ? "Listo, encendí " : "Listo, apagué ") + count + (count == 1 ? " luz." : " luces."));
        });
    }

    private void collectTiles(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int depth) {
        if (n == null || depth > 40) return;
        if (n.isClickable() && n.getChildCount() > 0) out.add(n);
        for (int i = 0; i < n.getChildCount(); i++) collectTiles(n.getChild(i), out, depth + 1);
    }

    // ---------- ayudantes ----------

    private boolean clickById(String[] ids) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        for (String id : ids) {
            try {
                List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByViewId(id);
                if (list != null) {
                    for (AccessibilityNodeInfo n : list) if (click(n)) return true;
                }
            } catch (Exception ignored) { }
        }
        return false;
    }

    private boolean clickByWords(String[] words) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        for (String w : words) {
            try {
                List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(w);
                if (list != null) {
                    for (AccessibilityNodeInfo n : list) {
                        CharSequence txt = n.getText() != null ? n.getText() : n.getContentDescription();
                        if (txt != null && txt.toString().trim().equalsIgnoreCase(w) && click(n)) return true;
                    }
                    for (AccessibilityNodeInfo n : list) if (click(n)) return true;
                }
            } catch (Exception ignored) { }
        }
        return false;
    }

    /** Toca el elemento o el primer padre que se pueda tocar. */
    private boolean click(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 5 && cur != null; i++) {
            if (cur.isClickable() && cur.isEnabled()) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            cur = cur.getParent();
        }
        return false;
    }
}
