package cr.nio;

import android.Manifest;
import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.MediaStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** El cerebro de Nio: entiende comandos en español y, si no es un comando, le pregunta a Gemini. */
public class Brain {

    public interface Out {
        void say(String text);
        void log(String who, String text);
        void thinking(boolean on);
        void stopListening();
    }

    public static final String PREFS = "nio";
    public static final String DEFAULT_MODEL = "gemini-3.5-flash-lite";

    private final Context ctx;
    private final Out out;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<String[]> history = new ArrayList<>();
    private static final Locale ES = new Locale("es", "CR");

    public Brain(Context ctx, Out out) {
        this.ctx = ctx.getApplicationContext();
        this.out = out;
    }

    // ---------- utilidades de texto ----------

    public static String norm(String s) {
        if (s == null) return "";
        String t = Normalizer.normalize(s.toLowerCase(ES), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
        t = t.replaceAll("[^a-z0-9: ]", " ").replaceAll("\\s+", " ").trim();
        return t;
    }

    private static final Map<String, Integer> NUM = new HashMap<>();
    static {
        String[] w = {"cero", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho",
                "nueve", "diez", "once", "doce"};
        for (int i = 0; i < w.length; i++) NUM.put(w[i], i);
        NUM.put("uno", 1); NUM.put("un", 1);
        NUM.put("quince", 15); NUM.put("veinte", 20); NUM.put("treinta", 30);
        NUM.put("cuarenta", 40); NUM.put("cincuenta", 50);
        NUM.put("media", 30); NUM.put("cuarto", 15);
    }

    private static int num(String tok) {
        if (tok == null) return -1;
        if (tok.matches("\\d{1,3}")) return Integer.parseInt(tok);
        Integer v = NUM.get(tok);
        return v == null ? -1 : v;
    }

    private static boolean has(String t, String... words) {
        for (String w : words) if (t.contains(w)) return true;
        return false;
    }

    private static String after(String t, String... keys) {
        for (String k : keys) {
            int i = t.indexOf(k);
            if (i >= 0) return t.substring(i + k.length()).trim();
        }
        return null;
    }

    // ---------- punto de entrada ----------

    public void handle(String raw) {
        if (raw == null) return;
        String t = norm(raw);
        if (t.isEmpty()) return;
        out.log("Tú", raw.trim());
        try {
            if (local(t)) return;
        } catch (Exception e) {
            out.say("No pude hacer eso. " + (e.getMessage() == null ? "" : e.getMessage()));
            return;
        }
        askAI(raw.trim());
    }

    private void reply(String text) {
        out.log("Nio", text);
        out.say(text);
    }

    private void launch(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    // ---------- comandos locales ----------

    // ---------- aprendizaje: rutinas y recuerdos ----------

    private SharedPreferences prefs() {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private JSONObject routines() {
        try { return new JSONObject(prefs().getString("routines", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    private JSONArray facts() {
        try { return new JSONArray(prefs().getString("facts", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    private static final Pattern LEARN = Pattern.compile(
            "(?:aprende|aprendete|apunta)(?: que)? cuando (?:yo )?(?:te )?(?:diga|digo) (.+?) (?:tienes que|tenes que|debes|vas a|quiero que|haz|hagas|haces|tu haces) (.+)");

    private static final Pattern LEARN2 = Pattern.compile(
            "(?:aprende|aprendete|apunta)(?: que)? cuando (?:yo )?(?:te )?(?:diga|digo) (.+?) ((?:pon|ponme|abre|abreme|llama|dime|enciende|prende|apaga|manda|busca|sube|baja|reproduce|llevame|temporizador|alarma|que)\\b.*)");

    private int depth = 0;

    /** Ejecuta los pasos de una rutina: "pon musica y luego dime la hora". */
    private void runSteps(String steps) throws Exception {
        String[] parts = steps.split(" y luego | luego | despues | y despues | y tambien | y ademas ");
        depth++;
        try {
            for (String s : parts) {
                String st = s.trim();
                if (st.isEmpty()) continue;
                if (!local(st)) askAI(st);
            }
        } finally { depth--; }
    }

    private boolean learning(String t) throws Exception {
        Matcher m = LEARN.matcher(t);
        boolean ok = m.find();
        if (!ok) { m = LEARN2.matcher(t); ok = m.find(); }
        if (ok) {
            String trig = m.group(1).trim();
            String act = m.group(2).trim();
            JSONObject r = routines();
            r.put(trig, act);
            prefs().edit().putString("routines", r.toString()).apply();
            reply("Aprendido. Cuando digas " + trig + ", voy a " + act + ".");
            return true;
        }
        String fact = after(t, "recuerda que ", "acuerdate que ", "acuerdate de que ", "no olvides que ", "anota que ");
        if (fact != null && !fact.isEmpty() && (t.startsWith("recuerda") || t.startsWith("acuerdate") || t.startsWith("no olvides") || t.startsWith("anota"))) {
            JSONArray f = facts();
            f.put(fact);
            while (f.length() > 60) f.remove(0);
            prefs().edit().putString("facts", f.toString()).apply();
            reply("Lo tendré presente.");
            return true;
        }
        if (has(t, "que has aprendido", "que te he ensenado", "cuales son tus rutinas", "que rutinas")) {
            JSONObject r = routines();
            JSONArray names = r.names();
            if (names == null || names.length() == 0) {
                reply("Todavía no me has enseñado rutinas. Dime por ejemplo: aprende que cuando diga buenos días, pon música y luego dime la hora.");
            } else {
                StringBuilder sb = new StringBuilder("Sé estas rutinas: ");
                for (int i = 0; i < names.length(); i++) {
                    if (i > 0) sb.append("; ");
                    sb.append(names.getString(i)).append(", ").append(r.getString(names.getString(i)));
                }
                reply(sb.append(".").toString());
            }
            return true;
        }
        if (has(t, "que sabes de mi", "que recuerdas")) {
            JSONArray f = facts();
            if (f.length() == 0) { reply("Aún no me has pedido que recuerde nada."); return true; }
            StringBuilder sb = new StringBuilder("Recuerdo que ");
            for (int i = 0; i < f.length(); i++) { if (i > 0) sb.append("; "); sb.append(f.getString(i)); }
            reply(sb.append(".").toString());
            return true;
        }
        String forget = after(t, "olvida la rutina ", "olvida el comando ", "borra la rutina ", "olvida lo de ");
        if (forget != null && !forget.isEmpty()) {
            JSONObject r = routines();
            JSONArray f = facts();
            boolean done = false;
            if (r.has(forget)) { r.remove(forget); done = true; }
            JSONArray nf = new JSONArray();
            for (int i = 0; i < f.length(); i++) {
                if (norm(f.getString(i)).contains(forget)) done = true; else nf.put(f.getString(i));
            }
            prefs().edit().putString("routines", r.toString()).putString("facts", nf.toString()).apply();
            reply(done ? "Listo, lo olvidé." : "No tenía nada guardado sobre " + forget + ".");
            return true;
        }
        if (depth == 0) {
            JSONObject r = routines();
            JSONArray names = r.names();
            if (names != null) {
                String best = null;
                for (int i = 0; i < names.length(); i++) {
                    String n = names.getString(i);
                    if (t.equals(n) || (" " + t + " ").contains(" " + n + " ")) {
                        if (best == null || n.length() > best.length()) best = n;
                    }
                }
                if (best != null) { runSteps(r.getString(best)); return true; }
            }
        }
        return false;
    }

    private boolean local(String t) throws Exception {
        if (learning(t)) return true;
        if (has(t, "deja de escuchar", "para de escuchar", "descansa", "desactivate", "apagate")) {
            reply("Entendido, señor. Me retiro.");
            main.postDelayed(out::stopListening, 2500);
            return true;
        }
        if (has(t, "nueva conversacion", "olvida todo", "borra la conversacion")) {
            history.clear();
            reply("Listo, empezamos de cero.");
            return true;
        }
        if (has(t, "que hora es", "dime la hora", "que horas son")) {
            reply("Son las " + new SimpleDateFormat("h:mm a", ES).format(new Date()) + ".");
            return true;
        }
        if (has(t, "que dia es", "que fecha es", "fecha de hoy", "dia es hoy")) {
            reply("Hoy es " + new SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy", ES).format(new Date()) + ".");
            return true;
        }
        if (t.contains("linterna") || t.contains("foco") || t.contains("flash")) {
            boolean on = !has(t, "apaga", "desactiva", "quita");
            torch(on);
            reply(on ? "Linterna encendida." : "Linterna apagada.");
            return true;
        }
        if (t.contains("volumen") || has(t, "silencio", "silencia")) {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            int s = AudioManager.STREAM_MUSIC;
            if (has(t, "silencio", "silencia", "mute")) {
                am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0);
                out.log("Nio", "Volumen en silencio.");
                return true;
            }
            am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0);
            if (has(t, "maximo", "todo")) {
                am.setStreamVolume(s, am.getStreamMaxVolume(s), AudioManager.FLAG_SHOW_UI);
            } else {
                int dir = has(t, "baja", "menos", "bajale") ? AudioManager.ADJUST_LOWER : AudioManager.ADJUST_RAISE;
                for (int i = 0; i < 3; i++) am.adjustStreamVolume(s, dir, i == 2 ? AudioManager.FLAG_SHOW_UI : 0);
            }
            reply("Listo.");
            return true;
        }
        if (t.contains("bateria") || t.contains("carga tengo")) {
            BatteryManager bm = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
            int p = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            reply("La batería está al " + p + " por ciento" + (bm.isCharging() ? ", y cargando." : "."));
            return true;
        }
        if (t.contains("alarma") || t.contains("despiertame") || t.contains("despierta me")) {
            int[] hm = parseTime(t);
            if (hm == null) { reply("¿A qué hora pongo la alarma?"); return true; }
            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, hm[0])
                    .putExtra(AlarmClock.EXTRA_MINUTES, hm[1])
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Nio")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            launch(i);
            reply(String.format(ES, "Alarma puesta a las %d:%02d.", hm[0], hm[1]));
            return true;
        }
        if (has(t, "temporizador", "cronometro", "timer", "avisame en", "avisame dentro")) {
            int secs = parseDuration(t);
            if (secs <= 0) { reply("¿De cuánto tiempo el temporizador?"); return true; }
            Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Nio")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            launch(i);
            reply("Temporizador listo.");
            return true;
        }
        if (t.contains("whatsapp") || t.contains("guasap") || t.contains("wasap")) {
            String rest = after(t, "whatsapp a ", "whatsapp para ", "guasap a ", "wasap a ", "mensaje a ");
            if (rest == null) {
                return openApp("whatsapp");
            }
            String name = rest, msg = "";
            for (String sep : new String[]{" diciendo ", " diciendole ", " que diga ", " que "}) {
                int i = rest.indexOf(sep);
                if (i > 0) { name = rest.substring(0, i); msg = rest.substring(i + sep.length()); break; }
            }
            String[] c = findContact(name.trim());
            if (c == null) return true;
            String phone = c[1].replaceAll("[^0-9]", "");
            if (phone.length() == 8) phone = "506" + phone;
            Uri u = Uri.parse("https://api.whatsapp.com/send?phone=" + phone + "&text=" + Uri.encode(msg));
            launch(new Intent(Intent.ACTION_VIEW, u));
            reply("Abriendo WhatsApp con " + c[0] + ". Solo dale enviar.");
            return true;
        }
        if (t.startsWith("llama") || t.contains(" llama a ") || t.startsWith("marca") || t.contains("llamar a ")) {
            String who = after(t, "llama a ", "llamar a ", "marca a ", "marcale a ", "llamale a ", "llama al ", "marca al ");
            if (who == null) who = after(t, "llama ", "marca ");
            if (who == null || who.isEmpty()) { reply("¿A quién llamo?"); return true; }
            String digits = who.replaceAll("[^0-9]", "");
            String number;
            String label;
            if (digits.length() >= 4 && digits.length() == who.replace(" ", "").length()) {
                number = digits; label = digits;
            } else {
                String[] c = findContact(who);
                if (c == null) return true;
                number = c[1]; label = c[0];
            }
            boolean canCall = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
            launch(new Intent(canCall ? Intent.ACTION_CALL : Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))));
            reply("Llamando a " + label + ".");
            return true;
        }
        if (t.startsWith("pon ") || t.startsWith("reproduce ") || t.startsWith("ponme ") || t.startsWith("toca ")) {
            String q = after(t, "pon la cancion ", "pon musica de ", "ponme musica de ", "pon ", "ponme ", "reproduce ", "toca ");
            if (q != null && !q.isEmpty() && !q.startsWith("una alarma") && !q.startsWith("un temporizador")) {
                playMusic(q);
                reply("Poniendo " + q + ".");
                return true;
            }
        }
        if (t.startsWith("busca ") || t.startsWith("buscame ") || t.startsWith("googlea ")) {
            String q = after(t, "busca en google ", "buscame ", "busca ", "googlea ");
            Intent i = new Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q);
            try { launch(i); } catch (Exception e) {
                launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))));
            }
            reply("Buscando " + q + ".");
            return true;
        }
        if (has(t, "llevame a ", "como llego a ", "navega a ", "ruta a ", "ruta para ")) {
            String q = after(t, "llevame a ", "como llego a ", "navega a ", "ruta a ", "ruta para ");
            launch(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))));
            reply("Abriendo la ruta a " + q + ".");
            return true;
        }
        if (t.startsWith("abre ") || t.startsWith("abrir ") || t.startsWith("abreme ") || t.contains(" abre ")) {
            String q = after(t, "abreme ", "abrir ", "abre la app de ", "abre la aplicacion de ", "abre el ", "abre la ", "abre ");
            if (q != null && !q.isEmpty()) return openApp(q);
        }
        return false;
    }

    // ---------- acciones del teléfono ----------

    private void torch(boolean on) throws Exception {
        CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
        for (String id : cm.getCameraIdList()) {
            Boolean f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            if (Boolean.TRUE.equals(f)) { cm.setTorchMode(id, on); return; }
        }
        throw new Exception("Este teléfono no tiene linterna.");
    }

    private boolean openApp(String q) {
        String want = norm(q);
        PackageManager pm = ctx.getPackageManager();
        Intent mainI = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(mainI, 0);
        ResolveInfo best = null;
        int bestScore = 0;
        for (ResolveInfo r : apps) {
            String label = norm(String.valueOf(r.loadLabel(pm)));
            int score = 0;
            if (label.equals(want)) score = 3;
            else if (label.startsWith(want) || want.startsWith(label)) score = 2;
            else if (label.contains(want) || want.contains(label)) score = 1;
            if (score > bestScore) { bestScore = score; best = r; }
        }
        if (best == null) {
            reply("No encontré la aplicación " + q + ".");
            return true;
        }
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(new ComponentName(best.activityInfo.packageName, best.activityInfo.name));
        launch(i);
        reply("Abriendo " + best.loadLabel(pm) + ".");
        return true;
    }

    private void playMusic(String q) {
        Intent i = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                .putExtra(SearchManager.QUERY, q);
        Intent yt = new Intent(i).setPackage("com.google.android.apps.youtube.music");
        try { launch(yt); return; } catch (Exception ignored) { }
        try { launch(i); return; } catch (Exception ignored) { }
        launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=" + Uri.encode(q))));
    }

    /** Devuelve {nombre, número} o null (y ya avisó por voz). */
    private String[] findContact(String name) {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            reply("Necesito permiso para ver tus contactos. Dámelo en Ajustes de Nio.");
            return null;
        }
        Uri uri = Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(name));
        String[] proj = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER};
        try (Cursor c = ctx.getContentResolver().query(uri, proj, null, null, null)) {
            if (c != null && c.moveToFirst()) return new String[]{c.getString(0), c.getString(1)};
        } catch (Exception ignored) { }
        reply("No encontré a " + name + " en tus contactos.");
        return null;
    }

    // ---------- interpretar horas y tiempos ----------

    static int[] parseTime(String t) {
        String s = t;
        int k = s.indexOf("alarma");
        if (k >= 0) s = s.substring(k);
        String[] tok = s.split(" ");
        int h = -1, m = 0;
        for (int i = 0; i < tok.length; i++) {
            String w = tok[i];
            if (w.contains(":")) {
                String[] p = w.split(":");
                if (p.length >= 2 && p[0].matches("\\d{1,2}") && p[1].matches("\\d{1,2}")) {
                    h = Integer.parseInt(p[0]); m = Integer.parseInt(p[1]); break;
                }
            }
            int n = num(w);
            if (n >= 0 && n <= 24 && !w.equals("un") && !w.equals("media") && !w.equals("cuarto")) {
                h = n;
                if (i + 2 < tok.length && tok[i + 1].equals("y")) {
                    int mm = num(tok[i + 2]);
                    if (mm >= 0 && mm < 60) {
                        m = mm;
                        if (i + 4 < tok.length && tok[i + 3].equals("y") && num(tok[i + 4]) >= 0 && num(tok[i + 4]) < 10) m += num(tok[i + 4]);
                    }
                } else if (i + 1 < tok.length && tok[i + 1].matches("\\d{2}")) {
                    m = Integer.parseInt(tok[i + 1]);
                }
                break;
            }
        }
        if (h < 0) return null;
        if (has(t, "tarde", "noche", "pm", "p m") && h < 12) h += 12;
        if (has(t, "manana", "am", "a m", "madrugada") && h == 12) h = 0;
        if (m > 59) m = 0;
        return new int[]{h % 24, m};
    }

    static int parseDuration(String t) {
        Matcher mt = Pattern.compile("(\\d+|un|una|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|once|doce|quince|veinte|treinta|cuarenta|cincuenta|media) (segundo|minuto|hora)").matcher(t);
        int total = 0;
        while (mt.find()) {
            int n = num(mt.group(1));
            if (mt.group(1).equals("media")) {
                total += mt.group(2).equals("hora") ? 1800 : 30;
                continue;
            }
            if (n < 0) continue;
            switch (mt.group(2)) {
                case "segundo": total += n; break;
                case "minuto": total += n * 60; break;
                default: total += n * 3600;
            }
        }
        if (t.contains("media hora") && total == 0) total = 1800;
        return total;
    }

    // ---------- Gemini ----------

    private void askAI(final String text) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        final String key = p.getString("key", "").trim();
        final String model = p.getString("model", DEFAULT_MODEL).trim().isEmpty() ? DEFAULT_MODEL : p.getString("model", DEFAULT_MODEL).trim();
        final String user = p.getString("name", "").trim();
        if (key.isEmpty()) {
            reply("Para conversar necesito tu clave de Gemini. Ponla en Ajustes.");
            return;
        }
        out.thinking(true);
        new Thread(() -> {
            String answer;
            try {
                answer = callGemini(key, model, user, text);
                synchronized (history) {
                    history.add(new String[]{"user", text});
                    history.add(new String[]{"model", answer});
                    while (history.size() > 16) history.remove(0);
                }
            } catch (Exception e) {
                answer = e.getMessage() == null ? "Tuve un problema al conectarme." : e.getMessage();
            }
            final String a = answer;
            main.post(() -> { out.thinking(false); deliver(a); });
        }).start();
    }

    /** Si Gemini devolvió comandos (CMD:), los ejecuta; si no, lo dice en voz alta. */
    private void deliver(String a) {
        StringBuilder speech = new StringBuilder();
        boolean any = false;
        for (String line : a.split("\n")) {
            String l = line.trim();
            if (l.toUpperCase(Locale.ROOT).startsWith("CMD:")) {
                any = true;
                String cmd = norm(l.substring(4));
                depth++;
                try {
                    if (!local(cmd)) speech.append("No supe hacer: ").append(cmd).append(". ");
                } catch (Exception e) {
                    speech.append("No pude hacer eso. ");
                } finally { depth--; }
            } else if (!l.isEmpty()) {
                speech.append(l).append(" ");
            }
        }
        String s = speech.toString().trim();
        if (!s.isEmpty()) reply(s);
        else if (!any) reply("No tengo una respuesta para eso.");
    }

    private String callGemini(String key, String model, String user, String text) throws Exception {
        String now = new SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy, h:mm a", ES).format(new Date());
        String sys = "Eres Nio, el asistente personal por voz de " + (user.isEmpty() ? "tu usuario" : user)
                + ", que vive en Costa Rica. Hablas español de Costa Rica, con un tono elegante, cálido y un toque de humor; "
                + "a veces lo llamas 'señor'. Tus respuestas se leen en voz alta: "
                + "sé breve (1 a 3 frases), sin listas, sin asteriscos, sin emojis ni formato. "
                + "Fecha y hora actual: " + now + ". "
                + "Si te piden algo del teléfono que no puedes hacer tú, explica cómo decirlo; tú ya sabes hacer esto por comando: "
                + "abrir apps, llamar a contactos, mandar WhatsApp, poner alarmas y temporizadores, linterna, volumen, batería, "
                + "poner música, buscar en Google y abrir rutas en el mapa. "
                + "IMPORTANTE: si el usuario quiere que hagas una de esas acciones pero lo dijo con otras palabras, "
                + "responde SOLO con líneas que empiecen con CMD: seguidas del comando en esta forma exacta, una por línea: "
                + "CMD: abre <app> | CMD: llama a <contacto> | CMD: whatsapp a <contacto> diciendo <mensaje> | "
                + "CMD: pon una alarma a las <hh:mm en 24 horas> | CMD: temporizador de <n> minutos | "
                + "CMD: enciende la linterna | CMD: apaga la linterna | CMD: sube el volumen | CMD: baja el volumen | "
                + "CMD: pon <canción o artista> | CMD: busca <texto> | CMD: llevame a <lugar> | CMD: que hora es. "
                + "Puedes añadir al final una línea normal para decirle algo breve. "
                + "El usuario también puede enseñarte rutinas diciendo 'aprende que cuando diga X, haz Y' "
                + "y pedirte que recuerdes cosas diciendo 'recuerda que...'.";
        JSONArray f = facts();
        if (f.length() > 0) {
            StringBuilder mem = new StringBuilder(" Cosas que el usuario te pidió recordar: ");
            for (int i = 0; i < f.length(); i++) mem.append("- ").append(f.getString(i)).append(" ");
            sys = sys + mem;
        }

        JSONArray contents = new JSONArray();
        synchronized (history) {
            for (String[] h : history) contents.put(turn(h[0], h[1]));
        }
        contents.put(turn("user", text));

        JSONObject body = new JSONObject()
                .put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", sys))))
                .put("contents", contents);

        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setConnectTimeout(15000);
        con.setReadTimeout(60000);
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        con.setRequestProperty("x-goog-api-key", key);
        try (OutputStream os = con.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = con.getResponseCode();
        InputStream is = code < 300 ? con.getInputStream() : con.getErrorStream();
        String resp = readAll(is);
        con.disconnect();

        if (code == 429) throw new Exception("Llegué al límite gratuito de Gemini por ahora. Intenta en un rato.");
        if (code == 400 || code == 401 || code == 403) {
            String msg = "";
            try { msg = new JSONObject(resp).getJSONObject("error").optString("message"); } catch (Exception ignored) { }
            if (msg.toLowerCase(Locale.ROOT).contains("api key")) throw new Exception("La clave de Gemini no es válida. Revísala en Ajustes.");
            throw new Exception("Gemini no aceptó la petición. " + msg);
        }
        if (code == 404) throw new Exception("No encontré el modelo " + model + ". Cámbialo en Ajustes.");
        if (code >= 300) throw new Exception("Gemini respondió con error " + code + ".");

        JSONObject j = new JSONObject(resp);
        JSONArray cands = j.optJSONArray("candidates");
        if (cands == null || cands.length() == 0) return "No tengo una respuesta para eso.";
        JSONObject content = cands.getJSONObject(0).optJSONObject("content");
        if (content == null) return "No tengo una respuesta para eso.";
        JSONArray parts = content.optJSONArray("parts");
        StringBuilder sb = new StringBuilder();
        if (parts != null) {
            for (int i = 0; i < parts.length(); i++) {
                JSONObject pt = parts.getJSONObject(i);
                if (pt.optBoolean("thought", false)) continue;
                sb.append(pt.optString("text", ""));
            }
        }
        String a = sb.toString().replaceAll("[*#_`]", "").trim();
        return a.isEmpty() ? "No tengo una respuesta para eso." : a;
    }

    private static JSONObject turn(String role, String text) throws Exception {
        return new JSONObject().put("role", role)
                .put("parts", new JSONArray().put(new JSONObject().put("text", text)));
    }

    private static String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[4096];
        int n;
        while ((n = is.read(b)) > 0) bo.write(b, 0, n);
        is.close();
        return bo.toString("UTF-8");
    }
}
