package cr.nio;

import android.Manifest;
import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.view.KeyEvent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** El cerebro de Beto: entiende comandos en español y, si no es un comando, le pregunta a Gemini. */
public class Brain {

    public interface Out {
        void say(String text);
        void log(String who, String text);
        void thinking(boolean on);
        void stopListening();
        void clearChat();
    }

    public static final String PREFS = "nio";
    public static final String DEFAULT_MODEL = "gemini-3.5-flash-lite";

    private final Context ctx;
    private final Out out;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<String[]> history = new ArrayList<>();
    private static final Locale ES = new Locale("es", "CR");

    public Brain(Context ctx, Out out) {
        this.ctx = ctx.getApplicationContext();
        this.out = out;
    }

    // ---------- utilidades de texto ----------

    public static String norm(String s) {
        if (s == null) return "";
        String t = Normalizer.normalize(s.toLowerCase(ES), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
        t = t.replaceAll("[^a-z0-9: ]", " ").replaceAll("\\s+", " ").trim();
        return t;
    }

    private static final Map<String, Integer> NUM = new HashMap<>();
    static {
        String[] w = {"cero", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho",
                "nueve", "diez", "once", "doce"};
        for (int i = 0; i < w.length; i++) NUM.put(w[i], i);
        NUM.put("uno", 1); NUM.put("un", 1);
        NUM.put("quince", 15); NUM.put("veinte", 20); NUM.put("treinta", 30);
        NUM.put("cuarenta", 40); NUM.put("cincuenta", 50);
        NUM.put("media", 30); NUM.put("cuarto", 15);
    }

    private static int num(String tok) {
        if (tok == null) return -1;
        if (tok.matches("\\d{1,3}")) return Integer.parseInt(tok);
        Integer v = NUM.get(tok);
        return v == null ? -1 : v;
    }

    private static boolean has(String t, String... words) {
        for (String w : words) if (t.contains(w)) return true;
        return false;
    }

    private static String after(String t, String... keys) {
        for (String k : keys) {
            int i = t.indexOf(k);
            if (i >= 0) return t.substring(i + k.length()).trim();
        }
        return null;
    }

    // ---------- punto de entrada ----------

    private String lastRaw = "";
    private String[] pendingWa = null;   // {nombre, teléfono} esperando el mensaje
    private boolean pendingPwd = false;   // esperando la contraseña del Wi-Fi

    public void handle(String raw) {
        if (raw == null) return;
        lastRaw = raw.trim();
        String t = norm(raw);
        if (t.isEmpty()) return;
        out.log("Tú", raw.trim());
        try {
            if (local(t)) return;
        } catch (Exception e) {
            out.say("No pude hacer eso. " + (e.getMessage() == null ? "" : e.getMessage()));
            return;
        }
        askAI(raw.trim());
    }

    private void reply(String text) {
        out.log("Nio", text);
        out.say(text);
    }

    private void launch(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    // ---------- comandos locales ----------

    // ---------- aprendizaje: rutinas y recuerdos ----------

    private SharedPreferences prefs() {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private JSONObject routines() {
        try { return new JSONObject(prefs().getString("routines", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    private JSONArray facts() {
        try { return new JSONArray(prefs().getString("facts", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    private static final Pattern LEARN = Pattern.compile(
            "(?:aprende|aprendete|apunta)(?: que)? cuando (?:yo )?(?:te )?(?:diga|digo) (.+?) (?:tienes que|tenes que|debes|vas a|quiero que|haz|hagas|haces|tu haces) (.+)");

    private static final Pattern LEARN2 = Pattern.compile(
            "(?:aprende|aprendete|apunta)(?: que)? cuando (?:yo )?(?:te )?(?:diga|digo) (.+?) ((?:pon|ponme|abre|abreme|llama|dime|enciende|prende|apaga|manda|mandale|envia|enviale|escribe|escribele|busca|sube|baja|reproduce|llevame|temporizador|alarma|cierra|descarga|que)\\b.*)");

    private int depth = 0;

    /** Ejecuta los pasos de una rutina, uno tras otro, con una pausa entre cada uno. */
    private void runSteps(String steps) {
        final List<String> list = new ArrayList<>();
        if (steps.contains("CMD:")) {
            for (String l : steps.split("\n")) {
                l = l.trim();
                if (l.toUpperCase(Locale.ROOT).startsWith("CMD:")) list.add(l.substring(4).trim());
            }
        } else {
            for (String part : steps.split(" y luego | luego | despues | y despues | y tambien | y ademas ")) {
                if (!part.trim().isEmpty()) list.add(part.trim());
            }
        }
        runStep(list, 0);
    }

    private void runStep(final List<String> list, final int i) {
        if (i >= list.size()) return;
        String st = list.get(i);
        long wait = 2500;
        String n = norm(st);
        if (n.startsWith("espera ")) {
            int secs = 3;
            Matcher m = Pattern.compile("(\\d+)").matcher(n);
            if (m.find()) secs = Integer.parseInt(m.group(1));
            wait = secs * 1000L;
        } else {
            depth++;
            try { if (!local(n)) askAI(st); } catch (Exception e) { reply("No pude hacer: " + st); }
            finally { depth--; }
            if (n.startsWith("abre") || n.contains("whatsapp")) wait = 4000;
        }
        main.postDelayed(() -> runStep(list, i + 1), wait);
    }

    /** Convierte lo que le enseñaste en comandos exactos para que siempre lo haga igual. */
    private void compileRoutine(final String trig, final String act) {
        final String key = key();
        if (key.isEmpty()) return;
        final String model = model();
        new Thread(() -> {
            try {
                String sys = "Convierte la instrucción del usuario en una lista de comandos para un asistente de teléfono. "
                        + "Responde SOLO con líneas que empiecen con CMD:, en este formato exacto: " + COMMANDS
                        + "Si hay que esperar a que algo cargue, usa CMD: espera <n> segundos. Nada más.";
                JSONArray c = new JSONArray().put(turn("user", act));
                String res = rawGemini(key, model, sys, c, false);
                StringBuilder cmds = new StringBuilder();
                for (String l : res.split("\n")) {
                    l = l.trim();
                    if (l.toUpperCase(Locale.ROOT).startsWith("CMD:")) cmds.append("CMD: ").append(l.substring(4).trim()).append("\n");
                }
                if (cmds.length() > 0) {
                    JSONObject r = routines();
                    r.put(trig, cmds.toString().trim());
                    prefs().edit().putString("routines", r.toString()).apply();
                }
            } catch (Exception ignored) { }
        }).start();
    }

    private boolean learning(String t) throws Exception {
        Matcher m = LEARN.matcher(t);
        boolean ok = m.find();
        if (!ok) { m = LEARN2.matcher(t); ok = m.find(); }
        if (ok) {
            String trig = m.group(1).trim();
            String act = m.group(2).trim();
            JSONObject r = routines();
            r.put(trig, act);
            prefs().edit().putString("routines", r.toString()).apply();
            compileRoutine(trig, act);
            reply("Aprendido. Cuando digas " + trig + ", voy a " + act + ".");
            return true;
        }
        String fact = after(t, "recuerda que ", "acuerdate que ", "acuerdate de que ", "no olvides que ", "anota que ");
        if (fact != null && !fact.isEmpty() && (t.startsWith("recuerda") || t.startsWith("acuerdate") || t.startsWith("no olvides") || t.startsWith("anota"))) {
            JSONArray f = facts();
            f.put(fact);
            while (f.length() > 60) f.remove(0);
            prefs().edit().putString("facts", f.toString()).apply();
            reply("Lo tendré presente.");
            return true;
        }
        if (has(t, "que has aprendido", "que te he ensenado", "cuales son tus rutinas", "que rutinas")) {
            JSONObject r = routines();
            JSONArray names = r.names();
            if (names == null || names.length() == 0) {
                reply("Todavía no me has enseñado rutinas. Dime por ejemplo: aprende que cuando diga buenos días, pon música y luego dime la hora.");
            } else {
                StringBuilder sb = new StringBuilder("Sé estas rutinas: ");
                for (int i = 0; i < names.length(); i++) {
                    if (i > 0) sb.append("; ");
                    sb.append(names.getString(i)).append(", ").append(r.getString(names.getString(i)).replace("CMD:", "").replace("\n", ", "));
                }
                reply(sb.append(".").toString());
            }
            return true;
        }
        if (has(t, "que sabes de mi", "que recuerdas")) {
            JSONArray f = facts();
            if (f.length() == 0) { reply("Aún no me has pedido que recuerde nada."); return true; }
            StringBuilder sb = new StringBuilder("Recuerdo que ");
            for (int i = 0; i < f.length(); i++) { if (i > 0) sb.append("; "); sb.append(f.getString(i)); }
            reply(sb.append(".").toString());
            return true;
        }
        String forget = after(t, "olvida la rutina ", "olvida el comando ", "borra la rutina ", "olvida lo de ");
        if (forget != null && !forget.isEmpty()) {
            JSONObject r = routines();
            JSONArray f = facts();
            boolean done = false;
            if (r.has(forget)) { r.remove(forget); done = true; }
            JSONArray nf = new JSONArray();
            for (int i = 0; i < f.length(); i++) {
                if (norm(f.getString(i)).contains(forget)) done = true; else nf.put(f.getString(i));
            }
            prefs().edit().putString("routines", r.toString()).putString("facts", nf.toString()).apply();
            reply(done ? "Listo, lo olvidé." : "No tenía nada guardado sobre " + forget + ".");
            return true;
        }
        if (depth == 0) {
            JSONObject r = routines();
            JSONArray names = r.names();
            if (names != null) {
                String best = null;
                for (int i = 0; i < names.length(); i++) {
                    String n = names.getString(i);
                    if (t.equals(n) || (" " + t + " ").contains(" " + n + " ")) {
                        if (best == null || n.length() > best.length()) best = n;
                    }
                }
                if (best != null) { track("rutina: " + best); runSteps(r.getString(best)); return true; }
            }
        }
        return false;
    }

    private boolean local(String t) throws Exception {
        // ¿estaba esperando el mensaje de WhatsApp?
        if (pendingWa != null && depth == 0) {
            String[] c = pendingWa;
            pendingWa = null;
            if (has(t, "cancela", "olvidalo", "nada")) { reply("Va, no le mando nada."); return true; }
            sendWhatsApp(c, lastRaw);
            return true;
        }
        if (pendingPwd && depth == 0) {
            pendingPwd = false;
            if (has(t, "cancela", "olvidalo", "dejalo")) { reply("Va, no la escribo."); return true; }
            BetoAccess a = BetoAccess.instance;
            String pwd = parsePassword(lastRaw);
            out.log("Beto", "Escribiendo la contraseña (" + pwd.length() + " caracteres)…");
            reply(a != null && a.typePassword(pwd) ? "Listo, la escribí y le di conectar." : "No encontré dónde escribir la contraseña.");
            return true;
        }
        if (learning(t)) return true;
        if (control(t)) return true;
        if (has(t, "deja de escuchar", "para de escuchar", "descansa", "desactivate", "apagate")) {
            reply("Va, me voy a descansar.");
            main.postDelayed(out::stopListening, 2500);
            return true;
        }
        if (has(t, "nueva conversacion", "olvida todo", "borra la conversacion")) {
            history.clear();
            out.clearChat();
            reply("Listo, empezamos de cero.");
            return true;
        }
        if (has(t, "que hora es", "dime la hora", "que horas son")) {
            reply("Son las " + new SimpleDateFormat("h:mm a", ES).format(new Date()) + ".");
            return true;
        }
        if (has(t, "que dia es", "que fecha es", "fecha de hoy", "dia es hoy")) {
            reply("Hoy es " + new SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy", ES).format(new Date()) + ".");
            return true;
        }
        if (t.contains("linterna") || t.contains("foco") || t.contains("flash")) {
            boolean on = !has(t, "apaga", "desactiva", "quita");
            torch(on);
            reply(on ? "Linterna encendida." : "Linterna apagada.");
            return true;
        }
        if (t.contains("volumen") || has(t, "silencio", "silencia")) {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            int s = AudioManager.STREAM_MUSIC;
            if (has(t, "silencio", "silencia", "mute")) {
                am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0);
                out.log("Beto", "Volumen en silencio.");
                return true;
            }
            am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0);
            if (has(t, "maximo", "todo")) {
                am.setStreamVolume(s, am.getStreamMaxVolume(s), AudioManager.FLAG_SHOW_UI);
            } else {
                int dir = has(t, "baja", "menos", "bajale") ? AudioManager.ADJUST_LOWER : AudioManager.ADJUST_RAISE;
                for (int i = 0; i < 3; i++) am.adjustStreamVolume(s, dir, i == 2 ? AudioManager.FLAG_SHOW_UI : 0);
            }
            reply("Listo.");
            return true;
        }
        if (t.contains("bateria") || t.contains("carga tengo")) {
            BatteryManager bm = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
            int p = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            reply("La batería está al " + p + " por ciento" + (bm.isCharging() ? ", y cargando." : "."));
            return true;
        }
        if (t.contains("alarma") || t.contains("despiertame") || t.contains("despierta me")) {
            int[] hm = parseTime(t);
            if (hm == null) { reply("¿A qué hora pongo la alarma?"); return true; }
            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, hm[0])
                    .putExtra(AlarmClock.EXTRA_MINUTES, hm[1])
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Beto")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            launch(i);
            reply(String.format(ES, "Alarma puesta a las %d:%02d.", hm[0], hm[1]));
            return true;
        }
        if (has(t, "temporizador", "cronometro", "timer", "avisame en", "avisame dentro")) {
            int secs = parseDuration(t);
            if (secs <= 0) { reply("¿De cuánto tiempo el temporizador?"); return true; }
            Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Beto")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
            launch(i);
            reply("Temporizador listo.");
            return true;
        }
        if (t.contains("whatsapp") || t.contains("guasap") || t.contains("wasap")
                || has(t, "mensaje a ", "mensajito a ", "escribele a ", "escribirle a ")) {
            String rest = after(t, "whatsapp a ", "whatsapp para ", "guasap a ", "wasap a ", "mensaje a ", "mensajito a ",
                    "escribele a ", "escribirle a ");
            if (rest == null) {
                return openApp("whatsapp");
            }
            String name = rest, msg = "";
            for (String sep : new String[]{" diciendo ", " diciendole ", " que diga ", " que le diga ", " que "}) {
                int i = rest.indexOf(sep);
                if (i > 0) { name = rest.substring(0, i); msg = rest.substring(i + sep.length()); break; }
            }
            name = name.replace(" por whatsapp", "").replace(" de whatsapp", "").replace(" por guasap", "")
                    .replace(" por wasap", "").trim();
            // el mensaje con mayúsculas y tildes, tal como lo dijiste
            if (!msg.isEmpty()) {
                String rawNorm = lastRaw;
                int k = norm(rawNorm).indexOf(msg);
                if (k >= 0 && norm(rawNorm).length() == rawNorm.length()) msg = rawNorm.substring(k, k + msg.length());
            }
            String[] c = findContact(name, BetoAccess.instance != null);
            if (c == null) {
                // no está en contactos: puede ser un grupo; lo busco dentro de WhatsApp
                BetoAccess acc = BetoAccess.instance;
                if (acc == null) { reply("No encontré a " + name + " en tus contactos."); return true; }
                if (msg.isEmpty()) { pendingWa = new String[]{name, ""}; reply("¿Qué le digo a " + name + "?"); return true; }
                sendToChat(name, msg);
                return true;
            }
            if (msg.isEmpty()) {
                pendingWa = c;
                reply("¿Qué le digo a " + c[0] + "?");
                return true;
            }
            sendWhatsApp(c, msg);
            return true;
        }
        if (t.startsWith("llama") || t.contains(" llama a ") || t.startsWith("marca") || t.contains("llamar a ")) {
            String who = after(t, "llama a ", "llamar a ", "marca a ", "marcale a ", "llamale a ", "llama al ", "marca al ");
            if (who == null) who = after(t, "llama ", "marca ");
            if (who == null || who.isEmpty()) { reply("¿A quién llamo?"); return true; }
            String digits = who.replaceAll("[^0-9]", "");
            String number;
            String label;
            if (digits.length() >= 4 && digits.length() == who.replace(" ", "").length()) {
                number = digits; label = digits;
            } else {
                String[] c = findContact(who);
                if (c == null) return true;
                number = c[1]; label = c[0];
            }
            boolean canCall = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
            launch(new Intent(canCall ? Intent.ACTION_CALL : Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))));
            track("llamar a " + label);
            reply("Llamando a " + label + ".");
            return true;
        }
        if (t.startsWith("pon ") || t.startsWith("reproduce ") || t.startsWith("ponme ") || t.startsWith("toca ")) {
            String q = after(t, "pon la cancion ", "pon musica de ", "ponme musica de ", "pon ", "ponme ", "reproduce ", "toca ");
            if (q != null && !q.isEmpty() && !q.startsWith("una alarma") && !q.startsWith("un temporizador")) {
                playMusic(q);
                reply("Poniendo " + q + ".");
                return true;
            }
        }
        if (t.startsWith("busca en google ") || t.startsWith("googlea ") || t.startsWith("abre google y busca ")) {
            String q = after(t, "busca en google ", "abre google y busca ", "googlea ");
            Intent i = new Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q);
            try { launch(i); } catch (Exception e) {
                launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))));
            }
            reply("Buscando " + q + ".");
            return true;
        }
        if (has(t, "llevame a ", "como llego a ", "navega a ", "ruta a ", "ruta para ")) {
            String q = after(t, "llevame a ", "como llego a ", "navega a ", "ruta a ", "ruta para ");
            launch(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))));
            reply("Abriendo la ruta a " + q + ".");
            return true;
        }
        if (t.startsWith("abre ") || t.startsWith("abrir ") || t.startsWith("abreme ") || t.contains(" abre ")) {
            String q = after(t, "abreme ", "abrir ", "abre la app de ", "abre la aplicacion de ", "abre el ", "abre la ", "abre ");
            if (q != null && !q.isEmpty()) return openApp(q);
        }
        return false;
    }

    // ---------- control total ----------

    private void sendToChat(final String name, String msg) {
        track("whatsapp a " + name);
        out.log("Beto", "Buscando " + name + " en WhatsApp…");
        BetoAccess.instance.sendToChat(name, msg, ok -> main.post(() ->
                reply(ok ? "Listo, le mandé el mensaje a " + name + "." : "No pude encontrar a " + name + " en WhatsApp.")));
    }

    private void sendWhatsApp(final String[] c, String msg) {
        if (c[1].isEmpty()) { sendToChat(c[0], msg); return; }
        track("whatsapp a " + c[0]);
        String phone = c[1].replaceAll("[^0-9]", "");
        if (phone.length() == 8) phone = "506" + phone;
        Uri u = Uri.parse("https://api.whatsapp.com/send?phone=" + phone + "&text=" + Uri.encode(msg));
        Intent i = new Intent(Intent.ACTION_VIEW, u);
        try { i.setPackage("com.whatsapp"); launch(i); }
        catch (Exception e) { launch(new Intent(Intent.ACTION_VIEW, u)); }
        BetoAccess a = BetoAccess.instance;
        if (a != null) {
            out.log("Beto", "Escribiéndole a " + c[0] + "…");
            a.sendWhatsAppSoon(() -> reply("Listo, le mandé el mensaje a " + c[0] + "."));
        } else {
            reply("Te dejé el mensaje escrito para " + c[0] + ". Dale enviar. Si activas el control total en Ajustes, lo envío yo solito.");
        }
    }

    /** Lee lo que hay en pantalla y se lo pasa a Gemini con la pregunta. */
    private void readScreenAndAsk(String question) {
        BetoAccess a = BetoAccess.instance;
        if (a == null) { needAccess(); return; }
        String txt = a.screenText();
        if (txt.trim().isEmpty()) { reply("No pude leer la pantalla."); return; }
        askAI(question + "\n\nTexto en pantalla:\n" + txt, false);
    }

    /**
     * Convierte la contraseña dictada en texto. Si la deletreas ("ce a ese a uno dos arroba"),
     * arma letra por letra; si dices palabras completas, las junta sin espacios.
     */
    static String parsePassword(String raw) {
        String s = raw.trim();
        String n = norm(s);
        String[] tok = n.split(" ");
        Map<String, String> sym = new HashMap<>();
        String[][] pairs = {{"arroba", "@"}, {"guion", "-"}, {"punto", "."}, {"numeral", "#"}, {"gato", "#"}, {"asterisco", "*"},
                {"espacio", " "}, {"dolar", "$"}, {"porcentaje", "%"}, {"exclamacion", "!"}, {"interrogacion", "?"},
                {"slash", "/"}, {"diagonal", "/"}, {"ampersand", "&"}, {"mas", "+"}, {"igual", "="}, {"coma", ","},
                {"cero", "0"}, {"uno", "1"}, {"dos", "2"}, {"tres", "3"}, {"cuatro", "4"}, {"cinco", "5"}, {"seis", "6"},
                {"siete", "7"}, {"ocho", "8"}, {"nueve", "9"},
                {"a", "a"}, {"be", "b"}, {"ce", "c"}, {"de", "d"}, {"e", "e"}, {"efe", "f"}, {"ge", "g"}, {"hache", "h"},
                {"i", "i"}, {"jota", "j"}, {"ka", "k"}, {"ele", "l"}, {"eme", "m"}, {"ene", "n"}, {"o", "o"}, {"pe", "p"},
                {"cu", "q"}, {"erre", "r"}, {"ere", "r"}, {"ese", "s"}, {"te", "t"}, {"u", "u"}, {"uve", "v"}, {"ve", "v"},
                {"doble", ""}, {"equis", "x"}, {"ye", "y"}, {"griega", "y"}, {"zeta", "z"}, {"seta", "z"}};
        for (String[] pr : pairs) sym.put(pr[0], pr[1]);
        int spelled = 0;
        for (String t : tok) if (t.length() == 1 || sym.containsKey(t) || t.matches("\\d+") || t.equals("mayuscula") || t.equals("bajo")) spelled++;
        if (tok.length >= 3 && spelled == tok.length) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < tok.length; i++) {
                String t = tok[i];
                if (t.equals("mayuscula")) {
                    if (sb.length() > 0) {
                        char c = sb.charAt(sb.length() - 1);
                        sb.setCharAt(sb.length() - 1, Character.toUpperCase(c));
                    }
                    continue;
                }
                if (t.equals("bajo") && sb.length() > 0 && sb.charAt(sb.length() - 1) == '-') { sb.setCharAt(sb.length() - 1, '_'); continue; }
                if (t.equals("doble") && i + 1 < tok.length && (tok[i + 1].equals("ve") || tok[i + 1].equals("u") || tok[i + 1].equals("uve"))) {
                    sb.append('w'); i++; continue;
                }
                if (t.equals("griega") && sb.length() > 0 && sb.charAt(sb.length() - 1) == 'i') { sb.setCharAt(sb.length() - 1, 'y'); continue; }
                String v = sym.get(t);
                sb.append(v != null ? v : t);
            }
            return sb.toString();
        }
        // palabras completas: se juntan sin espacios, respetando lo que entendió el teléfono
        return s.replace(" ", "");
    }

    private void mediaKey(int code) {
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
    }

    private boolean needAccess() {
        if (BetoAccess.instance != null) return false;
        reply("Para eso necesito el control total. Actívalo en Ajustes de Beto, en Control total.");
        return true;
    }

    private boolean control(String t) {
        BetoAccess a = BetoAccess.instance;
        // Google Home: luces y aparatos inteligentes
        boolean homeWord = has(t, "luz", "luces", "lampara", "bombillo", "enchufe", "abanico", "ventilador", "aire acondicionado",
                "google home", "en home", "la tele", "el televisor")
                || (t.contains("foco") && has(t, " de la ", " del ", " de mi "));
        if (homeWord && has(t, "apaga", "prende", "enciende", "activa", "desactiva", "quita la", "pon la")) {
            if (needAccess()) return true;
            boolean on = !has(t, "apaga", "desactiva", "quita");
            if (has(t, "todas las luces", "todas las lamparas", "todos los bombillos", "todas las lampara", "las luces de la casa")) {
                out.log("Beto", "Abriendo Google Home…");
                a.homeAllLights(on, msg -> main.post(() -> reply(msg)));
                return true;
            }
            String dev = after(t, "apaga la ", "apaga el ", "apaga los ", "apaga las ", "apaga ", "prende la ", "prende el ",
                    "prende los ", "prende las ", "prende ", "enciende la ", "enciende el ", "enciende ", "activa la ", "activa el ",
                    "activa ", "desactiva la ", "desactiva el ", "desactiva ", "quita la ", "pon la ");
            if (dev == null || dev.isEmpty()) { reply("¿Cuál aparato de Google Home?"); return true; }
            dev = dev.replace(" en google home", "").replace(" en home", "").trim();
            // nombres a probar: completo y sin "luz de la ..." (por ejemplo "luz de la sala" -> "sala")
            String shortName = dev.replaceFirst("^(la |el |las |los )?(luz|luces|lampara|bombillo|foco|enchufe|abanico|ventilador)( de la | del | de | )?", "").trim();
            String[] names = shortName.isEmpty() || shortName.equals(dev) ? new String[]{dev} : new String[]{dev, shortName};
            track("google home: " + dev);
            out.log("Beto", "Abriendo Google Home…");
            a.homeDevice(names, on, msg -> main.post(() -> reply(msg)));
            return true;
        }
        // cámara
        if (has(t, "toma una foto", "tomame una foto", "toma foto", "saca una foto", "sacame una foto", "tomate una foto",
                "toma la foto", "tomanos una foto", "selfie", "selfi", "autofoto")) {
            boolean front = has(t, "selfie", "selfi", "autofoto", "camara de adelante", "camara frontal", "tomate", "tomanos");
            if (a == null) {
                Intent i = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                launch(i);
                reply("Te abrí la cámara. Para que tome la foto solito, activa el control total.");
                return true;
            }
            reply(front ? "Sonríe… va la selfie." : "Va la foto, quédate quieto.");
            main.postDelayed(() -> a.takePhoto(front, ok -> main.post(() -> out.log("Beto", ok ? "Foto tomada." : "No pude tomar la foto."))), 1800);
            return true;
        }
        // Bluetooth
        if (t.contains("bluetooth") || t.contains("blutu") || t.contains("bluetu")) {
            if (needAccess()) return true;
            boolean on = !has(t, "apaga", "desactiva", "quita");
            String dev = after(t, "conectate a ", "conectate con ", "conecta a ", "conecta con ", "conectarte a ", "conectate al ", "conecta el ", "conecta la ");
            if (dev != null) dev = dev.replace("por bluetooth", "").replace("bluetooth", "").trim();
            out.log("Beto", on ? "Prendiendo el Bluetooth…" : "Apagando el Bluetooth…");
            a.bluetooth(on, dev, msg -> main.post(() -> reply(msg)));
            return true;
        }
        // Wi-Fi
        if (t.contains("wifi") || t.contains("wi fi") || t.contains("guifi") || t.contains("wuifi") || t.contains("red inalambrica")) {
            if (needAccess()) return true;
            boolean on = !has(t, "apaga", "desactiva", "quita");
            String net = after(t, "conectate a la red ", "conectate a ", "conectate al ", "conecta a la red ", "conecta a ", "red ");
            if (net != null) net = net.replace("del wifi", "").replace("de wifi", "").replace("wifi", "").replace("wi fi", "").trim();
            final String fnet = net;
            out.log("Beto", on ? "Prendiendo el Wi-Fi…" : "Apagando el Wi-Fi…");
            a.wifi(on, net, msg -> main.post(() -> {
                if ("PASSWORD".equals(msg)) {
                    pendingPwd = true;
                    reply("La red " + fnet + " pide contraseña. ¿Cuál es? Si tiene mayúsculas o símbolos, deletréamela.");
                } else {
                    reply(msg);
                }
            }));
            return true;
        }
        // colgar
        if (has(t, "corta la llamada", "cuelga", "colgar", "termina la llamada", "finaliza la llamada", "corta la llamada")) {
            boolean ok = false;
            try {
                if (ctx.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED) {
                    android.telecom.TelecomManager tm = (android.telecom.TelecomManager) ctx.getSystemService(Context.TELECOM_SERVICE);
                    ok = tm.endCall();
                }
            } catch (Exception ignored) { }
            if (!ok && a != null) ok = a.endCall();
            out.log("Beto", ok ? "Llamada terminada." : "No pude colgar.");
            if (!ok) reply("No pude colgar la llamada. Tócame o cuelga vos.");
            return true;
        }
        // YouTube: adelantar y devolver
        if (has(t, "adelanta", "devuelve", "devuelvete", "retrocede", "atrasa", "regresa el video", "echale para atras", "echale para adelante")) {
            if (needAccess()) return true;
            boolean fwd = has(t, "adelanta", "para adelante");
            int secs = 10;
            Matcher m = Pattern.compile("(\\d+|un|una|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|quince|veinte|treinta|media) (segundo|minuto)").matcher(t);
            if (m.find()) {
                int n = m.group(1).equals("media") ? 30 : num(m.group(1));
                if (n < 0) n = 1;
                secs = m.group(2).equals("minuto") ? (m.group(1).equals("media") ? 30 : n * 60) : n;
            }
            int taps = Math.max(1, Math.round(secs / 10f));
            a.seek(fwd, Math.min(taps, 60));
            reply((fwd ? "Adelantando " : "Devolviendo ") + (secs >= 60 ? (secs / 60) + (secs >= 120 ? " minutos." : " minuto.") : secs + " segundos."));
            return true;
        }
        // leer la pantalla
        if (has(t, "lee la pantalla", "que dice la pantalla", "que hay en la pantalla", "que ves en la pantalla",
                "resume la pantalla", "resumeme la pantalla", "leeme la pantalla", "lee lo que hay")) {
            if (needAccess()) return true;
            readScreenAndAsk("Esto aparece ahorita en la pantalla del teléfono. Resúmelo en pocas frases: " + lastRaw);
            return true;
        }
        // tocar un botón por su texto (nunca pagar)
        if (t.startsWith("toca ") || t.startsWith("dale clic a ") || t.startsWith("dale click a ") || t.startsWith("presiona ")
                || t.startsWith("selecciona ") || t.startsWith("escoge ") || t.startsWith("abre la promo ") || t.startsWith("dale a ")) {
            if (needAccess()) return true;
            String q = after(t, "dale clic a ", "dale click a ", "abre la promo ", "toca el boton ", "toca la ", "toca el ", "toca ",
                    "presiona ", "selecciona ", "escoge ", "dale a ");
            int r = a.clickText(q);
            if (r == -1) reply("Ese botón es para pagar o confirmar la compra. Ese lo tocas vos, por seguridad.");
            else reply(r == 1 ? "Listo." : "No encontré " + q + " en la pantalla.");
            return true;
        }
        if (has(t, "pidelo", "compralo", "ordenalo", "pide esa", "pide ese", "compra esa", "compra ese", "pagalo", "haz el pedido")) {
            reply("Te ayudo a dejar todo listo, pero el botón de pagar lo tocas vos para confirmar. Dime qué toco, por ejemplo: toca agregar.");
            return true;
        }
        // Uber Eats
        if (t.contains("uber eats") || t.contains("ubereats") || t.contains("uber its")) {
            String q = after(t, "promociones de ", "promos de ", "ofertas de ", "busca ", "buscame ");
            if (q != null) q = q.replace("en uber eats", "").replace("en ubereats", "").replace("y dime cuales son las mas atractivas", "").trim();
            if (q == null || q.isEmpty()) return openApp("uber eats");
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.ubereats.com/search?q=" + Uri.encode(q)));
            try { i.setPackage("com.ubercab.eats"); launch(i); }
            catch (Exception e) { openApp("uber eats"); }
            track("uber eats: " + q);
            if (a == null) { reply("Te abrí Uber Eats buscando " + q + ". Con el control total te puedo leer las promos."); return true; }
            out.log("Beto", "Buscando " + q + " en Uber Eats…");
            final String qq = q;
            main.postDelayed(() -> readScreenAndAsk("Esto aparece en Uber Eats buscando " + qq
                    + ". Dime en pocas frases cuáles promociones u ofertas son las más atractivas y por qué, con precios si aparecen."), 8000);
            return true;
        }
        // Spotify: buscar y descargar una playlist
        if (t.contains("spotify")) {
            String q = after(t, "playlist de ", "lista de ", "playlist ", "busca ", "buscame ", "pon ");
            if (q != null) q = q.replace("en spotify", "").replace("y descargala", "").replace("y ponla a descargar", "")
                    .replace("ponla a descargar", "").replace("descargala", "").trim();
            if (q == null || q.isEmpty()) return openApp("spotify");
            boolean download = has(t, "descarga", "bajala", "bajar");
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(q)));
            try { i.setPackage("com.spotify.music"); launch(i); }
            catch (Exception e) { return openApp("spotify"); }
            track("spotify: " + q);
            if (download) {
                if (a == null) { reply("Te abrí Spotify con " + q + ". Para descargarla yo solito necesito el control total."); return true; }
                out.log("Beto", "Buscando " + q + " en Spotify…");
                a.spotifyDownload(q, msg -> main.post(() -> reply(msg)));
            } else {
                reply("Buscando " + q + " en Spotify.");
                final String fq = q;
                if (a != null) main.postDelayed(() -> a.openFirstResult(fq), 3500);
            }
            return true;
        }
        // descargas
        if (t.startsWith("descarga") || t.startsWith("bajame") || t.startsWith("baja este") || t.startsWith("baja esta")) {
            String url = null;
            java.util.regex.Matcher m = Pattern.compile("(https?://\\S+|www\\.\\S+)").matcher(lastRaw);
            if (m.find()) url = m.group(1);
            if (url == null && a != null) url = a.findUrlOnScreen();
            if (url == null) {
                reply("No encontré qué descargar. Abre la página o el archivo en el navegador, o compárteme el enlace con el botón Compartir y escoges Beto.");
                return true;
            }
            reply(Downloads.start(ctx, url));
            return true;
        }
        // investigar en internet
        if (t.startsWith("investiga") || t.startsWith("averigua") || t.startsWith("busca en internet") || t.startsWith("buscame en internet")
                || ((t.startsWith("busca ") || t.startsWith("buscame ")) && !has(t, "foto", "video", "cancion", "en google", "uber", "spotify"))) {
            askAI(lastRaw, true);
            return true;
        }
        // borrar lo que se mostró
        if (has(t, "borra eso", "borralo", "borra la respuesta", "elimina la respuesta", "elimina eso", "limpia la pantalla",
                "borra la pantalla", "borra todo eso")) {
            history.clear();
            out.clearChat();
            reply("Listo, borrado.");
            return true;
        }
        // música
        if (has(t, "pausa", "paralo", "detenlo", "pausalo", "para el video", "para la musica", "deten la musica", "quita la musica", "quita la cancion", "detente la musica")) {
            mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE);
            reply("Listo, en pausa.");
            return true;
        }
        if (has(t, "siguiente cancion", "pasa la cancion", "otra cancion", "cambia la cancion")) {
            mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT);
            reply("Va la siguiente.");
            return true;
        }
        if (has(t, "cancion anterior", "la anterior")) {
            mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS);
            reply("Regreso a la anterior.");
            return true;
        }
        if (has(t, "sigue la musica", "continua la musica", "reanuda", "dale play", "ponle play", "ponle reproduccion",
                "reproducelo", "continua el video", "sigue el video") || t.equals("play") || t.equals("reproduce")) {
            mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY);
            reply("Dale.");
            return true;
        }
        // cerrar todo
        if (has(t, "cierra todo", "cierra todas", "cierra las aplicaciones", "cierra las apps", "cierra todas las apps",
                "limpia las aplicaciones", "limpia las apps", "cierra lo que esta abierto")) {
            if (needAccess()) return true;
            mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE);
            a.closeAll(() -> reply("Listo, cerré todas las aplicaciones."));
            return true;
        }
        // cerrar una app o quitar lo que está en pantalla
        if (t.startsWith("cierra") || t.startsWith("cerra") || t.startsWith("quita") || t.startsWith("ya quita")
                || t.startsWith("sal de") || t.startsWith("salte de") || t.equals("quitala") || t.equals("quitalo")) {
            if (needAccess()) return true;
            String what = after(t, "cierra el ", "cierra la ", "cierra ", "cerra ", "quita el ", "quita la ", "quita ", "sal de ", "salte de ");
            mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE);
            a.home();
            if (what != null && !what.isEmpty() && !what.startsWith("la") && !what.startsWith("lo")) {
                reply("Listo, cerré " + what + ".");
            } else {
                reply("Listo, lo quité.");
            }
            return true;
        }
        if (t.equals("atras") || has(t, "ve atras", "vuelve atras", "regresa", "devuelvete", "pagina anterior")) {
            if (needAccess()) return true;
            a.back();
            reply("Listo.");
            return true;
        }
        if (has(t, "ve al inicio", "pantalla de inicio", "pantalla principal", "al escritorio")) {
            if (needAccess()) return true;
            a.home();
            reply("Listo, en el inicio.");
            return true;
        }
        if (has(t, "abre las notificaciones", "muestrame las notificaciones", "baja las notificaciones")) {
            if (needAccess()) return true;
            a.notifications();
            reply("Ahí están tus notificaciones.");
            return true;
        }
        if (has(t, "captura de pantalla", "toma una captura", "toma captura", "pantallazo")) {
            if (needAccess()) return true;
            reply("Va la captura.");
            main.postDelayed(a::screenshot, 1500);
            return true;
        }
        if (has(t, "bloquea el telefono", "bloquea la pantalla", "bloquea el celular", "apaga la pantalla")) {
            if (needAccess()) return true;
            reply("Bloqueando.");
            main.postDelayed(a::lock, 1500);
            return true;
        }
        // fotos
        if (t.contains("foto") && has(t, "busca", "muestra", "ensena", "abre", "pon", "quiero ver")) {
            String q = after(t, "fotos de ", "foto de ", "fotos del ", "foto del ");
            if (q == null) q = "";
            q = q.replaceFirst("^(un |una |unos |unas |el |la |los |las )", "")
                    .replace(" en google fotos", "").replace(" en internet", "").replace(" en google", "").trim();
            if (has(t, "en internet", "en google ", "de internet") && !t.contains("google fotos")) {
                launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?tbm=isch&q=" + Uri.encode(q))));
                reply("Aquí tienes fotos de " + q + " de internet.");
            } else {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://photos.google.com/search/" + Uri.encode(q)));
                try { i.setPackage("com.google.android.apps.photos"); launch(i); }
                catch (Exception e) {
                    launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?tbm=isch&q=" + Uri.encode(q))));
                }
                reply("Buscando fotos de " + q + ".");
            }
            return true;
        }
        // videos de YouTube
        if (t.contains("video") || t.contains("youtube")) {
            String q = after(t, "videos de ", "video de ", "video del ", "en youtube ", "youtube ");
            if (q != null) q = q.replace("en youtube", "").trim();
            if (q != null && !q.isEmpty() && has(t, "pon", "busca", "muestra", "reproduce", "quiero ver", "abre")) {
                Intent i = new Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q);
                try { launch(i); }
                catch (Exception e) {
                    launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))));
                }
                track("youtube: " + q);
                if (a != null) {
                    reply("Poniendo un video de " + q + ".");
                    main.postDelayed(a::playFirstYouTube, 4500);
                } else {
                    reply("Buscando videos de " + q + " en YouTube.");
                }
                return true;
            }
        }
        // canciones
        if (has(t, "buscame la cancion ", "busca la cancion ", "ponme la cancion ", "pon la cancion ", "quiero oir ", "quiero escuchar ")) {
            String q = after(t, "buscame la cancion ", "busca la cancion ", "ponme la cancion ", "pon la cancion ", "quiero oir ", "quiero escuchar ");
            if (q != null && !q.isEmpty()) {
                q = q.replaceFirst("^de ", "");
                playMusic(q);
                reply("Poniendo " + q + ".");
                return true;
            }
        }
        // cantar
        if (t.startsWith("canta") || t.startsWith("cantame") || has(t, "echate una cancion", "cantanos")) {
            String tema = after(t, "cantame una cancion de ", "cantame una cancion sobre ", "canta una cancion de ",
                    "canta una cancion sobre ", "cantame de ", "canta de ", "cantame ", "canta ");
            askAI("Cántame una canción corta, alegre y con rima, de 4 a 6 versos"
                    + (tema != null && !tema.isEmpty() && !tema.startsWith("una cancion") ? " sobre " + tema : "")
                    + ". Escribe solo la letra, sin título ni explicaciones.");
            return true;
        }
        return false;
    }

    // ---------- acciones del teléfono ----------

    private void torch(boolean on) throws Exception {
        CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
        for (String id : cm.getCameraIdList()) {
            Boolean f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            if (Boolean.TRUE.equals(f)) { cm.setTorchMode(id, on); return; }
        }
        throw new Exception("Este teléfono no tiene linterna.");
    }

    private boolean openApp(String q) {
        String want = norm(q);
        PackageManager pm = ctx.getPackageManager();
        Intent mainI = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(mainI, 0);
        ResolveInfo best = null;
        int bestScore = 0;
        for (ResolveInfo r : apps) {
            String label = norm(String.valueOf(r.loadLabel(pm)));
            int score = 0;
            if (label.equals(want)) score = 3;
            else if (label.startsWith(want) || want.startsWith(label)) score = 2;
            else if (label.contains(want) || want.contains(label)) score = 1;
            if (score > bestScore) { bestScore = score; best = r; }
        }
        if (best == null) {
            reply("No encontré la aplicación " + q + ".");
            return true;
        }
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(new ComponentName(best.activityInfo.packageName, best.activityInfo.name));
        launch(i);
        track("abrir " + best.loadLabel(pm));
        reply("Abriendo " + best.loadLabel(pm) + ".");
        return true;
    }

    private void playMusic(String q) {
        track("música: " + q);
        Intent i = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                .putExtra(SearchManager.QUERY, q);
        Intent yt = new Intent(i).setPackage("com.google.android.apps.youtube.music");
        try { launch(yt); return; } catch (Exception ignored) { }
        try { launch(i); return; } catch (Exception ignored) { }
        launch(new Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=" + Uri.encode(q))));
    }

    /** Devuelve {nombre, número} o null (y ya avisó por voz). */
    private String[] findContact(String name) { return findContact(name, false); }

    private String[] findContact(String name, boolean quiet) {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            reply("Necesito permiso para ver tus contactos. Dámelo en Ajustes de Beto.");
            return null;
        }
        Uri uri = Uri.withAppendedPath(ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(name));
        String[] proj = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER};
        try (Cursor c = ctx.getContentResolver().query(uri, proj, null, null, null)) {
            if (c != null && c.moveToFirst()) return new String[]{c.getString(0), c.getString(1)};
        } catch (Exception ignored) { }
        // segundo intento: compara sin tildes ni ñ (por ejemplo "Ñipi" o "Princesa Valentina")
        String want = norm(name);
        String[] best = null;
        int bestScore = 0;
        try (Cursor c = ctx.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj, null, null, null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String dn = c.getString(0);
                    String n = norm(dn);
                    int score = n.equals(want) ? 3 : n.startsWith(want) ? 2 : (n.contains(want) || want.contains(n) && n.length() > 2) ? 1 : 0;
                    if (score > bestScore) { bestScore = score; best = new String[]{dn, c.getString(1)}; }
                }
            }
        } catch (Exception ignored) { }
        if (best != null) return best;
        if (quiet) return null;
        reply("No encontré a " + name + " en tus contactos.");
        return null;
    }

    // ---------- interpretar horas y tiempos ----------

    static int[] parseTime(String t) {
        String s = t;
        int k = s.indexOf("alarma");
        if (k >= 0) s = s.substring(k);
        String[] tok = s.split(" ");
        int h = -1, m = 0;
        for (int i = 0; i < tok.length; i++) {
            String w = tok[i];
            if (w.contains(":")) {
                String[] p = w.split(":");
                if (p.length >= 2 && p[0].matches("\\d{1,2}") && p[1].matches("\\d{1,2}")) {
                    h = Integer.parseInt(p[0]); m = Integer.parseInt(p[1]); break;
                }
            }
            int n = num(w);
            if (n >= 0 && n <= 24 && !w.equals("un") && !w.equals("media") && !w.equals("cuarto")) {
                h = n;
                if (i + 2 < tok.length && tok[i + 1].equals("y")) {
                    int mm = num(tok[i + 2]);
                    if (mm >= 0 && mm < 60) {
                        m = mm;
                        if (i + 4 < tok.length && tok[i + 3].equals("y") && num(tok[i + 4]) >= 0 && num(tok[i + 4]) < 10) m += num(tok[i + 4]);
                    }
                } else if (i + 1 < tok.length && tok[i + 1].matches("\\d{2}")) {
                    m = Integer.parseInt(tok[i + 1]);
                }
                break;
            }
        }
        if (h < 0) return null;
        if (has(t, "tarde", "noche", "pm", "p m") && h < 12) h += 12;
        if (has(t, "manana", "am", "a m", "madrugada") && h == 12) h = 0;
        if (m > 59) m = 0;
        return new int[]{h % 24, m};
    }

    static int parseDuration(String t) {
        Matcher mt = Pattern.compile("(\\d+|un|una|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|once|doce|quince|veinte|treinta|cuarenta|cincuenta|media) (segundo|minuto|hora)").matcher(t);
        int total = 0;
        while (mt.find()) {
            int n = num(mt.group(1));
            if (mt.group(1).equals("media")) {
                total += mt.group(2).equals("hora") ? 1800 : 30;
                continue;
            }
            if (n < 0) continue;
            switch (mt.group(2)) {
                case "segundo": total += n; break;
                case "minuto": total += n * 60; break;
                default: total += n * 3600;
            }
        }
        if (t.contains("media hora") && total == 0) total = 1800;
        return total;
    }

    // ---------- Gemini ----------

    private static final String[] WEB_WORDS = {"investiga", "busca en internet", "buscame en internet", "noticia", "precio",
            "cuanto cuesta", "cuanto vale", "clima", "va a llover", "hoy", "ayer", "manana", "ultimo", "ultima", "quien gano",
            "resultado", "horario", "abre a que hora", "cierra a que hora", "tipo de cambio", "dolar", "partido", "actual",
            "este ano", "esta semana", "donde queda", "cerca de", "estreno", "promocion", "oferta", "como esta"};

    private void askAI(final String text) {
        String n = norm(text);
        boolean web = false;
        for (String w : WEB_WORDS) if (n.contains(w)) { web = true; break; }
        askAI(text, web);
    }

    private SharedPreferences sp() { return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    private String key() { return sp().getString("key", "").trim(); }

    private String model() {
        String m = sp().getString("model", DEFAULT_MODEL).trim();
        return m.isEmpty() ? DEFAULT_MODEL : m;
    }

    private void askAI(final String text, final boolean web) {
        final String key = key();
        final String model = model();
        final String user = sp().getString("name", "").trim();
        if (key.isEmpty()) {
            reply("Para conversar necesito tu clave de Gemini. Ponla en Ajustes.");
            return;
        }
        out.thinking(true);
        if (web) out.log("Beto", "Buscando en internet…");
        new Thread(() -> {
            String answer;
            try {
                answer = callGemini(key, model, user, text, web);
                synchronized (history) {
                    history.add(new String[]{"user", text.length() > 1500 ? text.substring(0, 1500) : text});
                    history.add(new String[]{"model", answer});
                    while (history.size() > 16) history.remove(0);
                }
            } catch (Exception e) {
                answer = e.getMessage() == null ? "Tuve un problema al conectarme." : e.getMessage();
            }
            final String a = answer;
            main.post(() -> { out.thinking(false); deliver(a); });
        }).start();
    }

    /** Si Gemini devolvió comandos (CMD:), los ejecuta; guarda recuerdos (MEMO:); lo demás lo dice. */
    private void deliver(String a) {
        StringBuilder speech = new StringBuilder();
        boolean any = false;
        for (String line : a.split("\n")) {
            String l = line.trim();
            String up = l.toUpperCase(Locale.ROOT);
            if (up.startsWith("MEMO:")) {
                saveFact(l.substring(5).trim());
            } else if (up.startsWith("CMD:")) {
                any = true;
                String cmd = norm(l.substring(4));
                depth++;
                try {
                    if (!local(cmd)) speech.append("No supe hacer: ").append(cmd).append(". ");
                } catch (Exception e) {
                    speech.append("No pude hacer eso. ");
                } finally { depth--; }
            } else if (!l.isEmpty()) {
                speech.append(l).append(" ");
            }
        }
        String s = speech.toString().trim();
        if (!s.isEmpty()) reply(s);
        else if (!any) reply("Listo.");
    }

    /** Guarda algo que aprendió de vos (sin repetir). */
    private void saveFact(String fact) {
        if (fact == null || fact.length() < 3) return;
        try {
            JSONArray f = facts();
            String nf = norm(fact);
            for (int i = 0; i < f.length(); i++) if (norm(f.getString(i)).equals(nf)) return;
            f.put(fact);
            while (f.length() > 80) f.remove(0);
            prefs().edit().putString("facts", f.toString()).apply();
        } catch (Exception ignored) { }
    }

    /** Lleva la cuenta de lo que más usas, para tenerlo más a mano. */
    private void track(String what) {
        try {
            JSONObject u = new JSONObject(prefs().getString("usage", "{}"));
            u.put(what, u.optInt(what, 0) + 1);
            prefs().edit().putString("usage", u.toString()).apply();
        } catch (Exception ignored) { }
    }

    private String topUsage() {
        try {
            JSONObject u = new JSONObject(prefs().getString("usage", "{}"));
            JSONArray names = u.names();
            if (names == null) return "";
            List<String> list = new ArrayList<>();
            for (int i = 0; i < names.length(); i++) list.add(names.getString(i));
            java.util.Collections.sort(list, (x, y) -> u.optInt(y, 0) - u.optInt(x, 0));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(8, list.size()); i++) {
                sb.append(list.get(i)).append(" (").append(u.optInt(list.get(i), 0)).append(" veces); ");
            }
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    private String callGemini(String key, String model, String user, String text, boolean web) throws Exception {
        String now = new SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy, h:mm a", ES).format(new Date());
        String sys = "Eres Beto, un perrito salchicha que es el asistente personal por voz de " + (user.isEmpty() ? "tu usuario" : user)
                + ", que vive en Costa Rica. Hablas español de Costa Rica, amigable, alegre y vacilón, con buen humor tico "
                + "pero respetuoso. Tus respuestas se leen en voz alta: "
                + "sé breve (1 a 4 frases), sin listas, sin asteriscos, sin emojis, sin enlaces ni formato. "
                + "Fecha y hora actual: " + now + ". "
                + (web ? "Tienes búsqueda de Google: úsala para dar datos actuales y concretos. " : "")
                + "Si el usuario quiere que hagas una acción del teléfono pero lo dijo con otras palabras, "
                + "responde SOLO con líneas que empiecen con CMD: seguidas del comando en esta forma exacta, una por línea: "
                + COMMANDS
                + "Puedes añadir al final una línea normal para decirle algo breve. "
                + "Si el usuario te cuenta algo duradero de su vida, su familia, su trabajo o sus gustos que valga la pena recordar, "
                + "agrega al final una línea aparte 'MEMO: <dato breve>' (esa línea no se lee en voz alta); no repitas recuerdos que ya tienes. "
                + "El usuario también puede enseñarte tareas diciendo 'aprende que cuando diga X, haz Y'.";
        JSONArray f = facts();
        if (f.length() > 0) {
            StringBuilder mem = new StringBuilder(" Lo que sabes del usuario: ");
            for (int i = 0; i < f.length(); i++) mem.append("- ").append(f.getString(i)).append(" ");
            sys = sys + mem;
        }
        String top = topUsage();
        if (!top.isEmpty()) sys = sys + " Lo que más te pide: " + top;

        JSONArray contents = new JSONArray();
        synchronized (history) {
            for (String[] h : history) contents.put(turn(h[0], h[1]));
        }
        contents.put(turn("user", text));
        try {
            return rawGemini(key, model, sys, contents, web);
        } catch (Exception e) {
            if (web && e.getMessage() != null && e.getMessage().startsWith("Gemini no aceptó")) {
                return rawGemini(key, model, sys, contents, false);   // sin búsqueda, por si el modelo no la permite
            }
            throw e;
        }
    }

    static final String COMMANDS = "CMD: abre <app> | CMD: llama a <contacto> | CMD: corta la llamada | "
            + "CMD: whatsapp a <contacto o grupo> diciendo <mensaje> | "
            + "CMD: pon una alarma a las <hh:mm en 24 horas> | CMD: temporizador de <n> minutos | "
            + "CMD: enciende la linterna | CMD: apaga la linterna | CMD: sube el volumen | CMD: baja el volumen | "
            + "CMD: pon <canción o artista> | CMD: investiga <tema> | CMD: llevame a <lugar> | CMD: que hora es | "
            + "CMD: cierra <app> | CMD: cierra todo | CMD: atras | CMD: ve al inicio | CMD: pausa | CMD: dale play | "
            + "CMD: siguiente cancion | CMD: adelanta <n> segundos | CMD: devuelve <n> segundos | "
            + "CMD: buscame fotos de <algo> | CMD: pon el video de <algo> | CMD: borra eso | CMD: toma captura | "
            + "CMD: lee la pantalla | CMD: toca <texto del botón> | CMD: busca <comida> en uber eats | "
            + "CMD: descarga en spotify la playlist <nombre> | CMD: descarga esto | CMD: espera <n> segundos. ";

    /** Llamada directa a Gemini. */
    private String rawGemini(String key, String model, String sys, JSONArray contents, boolean web) throws Exception {
        JSONObject body = new JSONObject()
                .put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", sys))))
                .put("contents", contents);
        if (web) body.put("tools", new JSONArray().put(new JSONObject().put("google_search", new JSONObject())));

        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setConnectTimeout(15000);
        con.setReadTimeout(90000);
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        con.setRequestProperty("x-goog-api-key", key);
        try (OutputStream os = con.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = con.getResponseCode();
        InputStream is = code < 300 ? con.getInputStream() : con.getErrorStream();
        String resp = readAll(is);
        con.disconnect();

        if (code == 429) throw new Exception("Llegué al límite gratuito de Gemini por ahora. Intenta en un rato.");
        if (code == 400 || code == 401 || code == 403) {
            String msg = "";
            try { msg = new JSONObject(resp).getJSONObject("error").optString("message"); } catch (Exception ignored) { }
            if (msg.toLowerCase(Locale.ROOT).contains("api key")) throw new Exception("La clave de Gemini no es válida. Revísala en Ajustes.");
            throw new Exception("Gemini no aceptó la petición. " + msg);
        }
        if (code == 404) throw new Exception("No encontré el modelo " + model + ". Cámbialo en Ajustes.");
        if (code >= 300) throw new Exception("Gemini respondió con error " + code + ".");

        JSONObject j = new JSONObject(resp);
        JSONArray cands = j.optJSONArray("candidates");
        if (cands == null || cands.length() == 0) return "No tengo una respuesta para eso.";
        JSONObject content = cands.getJSONObject(0).optJSONObject("content");
        if (content == null) return "No tengo una respuesta para eso.";
        JSONArray parts = content.optJSONArray("parts");
        StringBuilder sb = new StringBuilder();
        if (parts != null) {
            for (int i = 0; i < parts.length(); i++) {
                JSONObject pt = parts.getJSONObject(i);
                if (pt.optBoolean("thought", false)) continue;
                sb.append(pt.optString("text", ""));
            }
        }
        String a = sb.toString().replaceAll("[*#_`]", "").replaceAll("\\[\\d+(, ?\\d+)*\\]", "").trim();
        return a.isEmpty() ? "No tengo una respuesta para eso." : a;
    }

    private static JSONObject turn(String role, String text) throws Exception {
        return new JSONObject().put("role", role)
                .put("parts", new JSONArray().put(new JSONObject().put("text", text)));
    }

    private static String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[4096];
        int n;
        while ((n = is.read(b)) > 0) bo.write(b, 0, n);
        is.close();
        return bo.toString("UTF-8");
    }
}
