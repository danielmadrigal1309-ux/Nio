package cr.nio;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;

/**
 * Beto: perrito salchicha negro con café, dibujado con luces y sombras para que se vea en 3D.
 * Estados: dormido, despierto, escuchando (de pie, cola rápida), pensando (cabeza ladeada)
 * y hablando (mueve la boca).
 */
public class DogPainter {

    public static final int SLEEP = -1, IDLE = 0, LISTEN = 1, THINK = 2, SPEAK = 3;

    // medidas del dibujo (unidades propias)
    private static final float BW = 140f, BH = 114f;

    private static final int FUR = Color.rgb(32, 24, 20);
    private static final int FUR_HI = Color.rgb(92, 74, 64);
    private static final int FUR_SH = Color.rgb(12, 9, 8);
    private static final int TAN = Color.rgb(200, 118, 56);
    private static final int TAN_HI = Color.rgb(244, 178, 112);
    private static final int TAN_SH = Color.rgb(132, 70, 30);
    private static final int EAR = Color.rgb(44, 30, 24);
    private static final int EAR_HI = Color.rgb(104, 76, 62);

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path path = new Path();

    // valores suavizados para que los cambios de postura sean animados
    private float stand = 0f, headUp = 0f, tilt = 0f, earLift = 0f, eyesOpen = 0f, think = 0f;

    private static float approach(float cur, float target, float k) {
        return cur + (target - cur) * k;
    }

    private void fillOval(Canvas c, float l, float t, float rr, float b, Shader s) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(s);
        r.set(l, t, rr, b);
        c.drawOval(r, p);
        p.setShader(null);
    }

    private void fillRound(Canvas c, float l, float t, float rr, float b, float rad, Shader s) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(s);
        r.set(l, t, rr, b);
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
    }

    private static Shader radial(float cx, float cy, float rad, int hi, int mid, int sh) {
        return new RadialGradient(cx, cy, rad, new int[]{hi, mid, sh}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
    }

    private static Shader vertical(float y0, float y1, int top, int mid, int bottom) {
        return new LinearGradient(0, y0, 0, y1, new int[]{top, mid, bottom}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP);
    }

    /** Dibuja a Beto centrado en un área de w x h. t = segundos. */
    public void draw(Canvas c, float w, float h, int state, float t) {
        // objetivos según el estado
        float tStand = (state == SLEEP || state == IDLE) ? 0f : 1f;
        float tHead = state == SLEEP ? 0f : 1f;
        float tTilt = state == THINK ? 14f : state == LISTEN ? -5f * (float) Math.sin(t * 1.3) : 0f;
        float tEar = state == LISTEN ? 1f : state == THINK ? 0.5f : 0f;
        float tThink = state == THINK ? 1f : 0f;
        stand = approach(stand, tStand, 0.12f);
        headUp = approach(headUp, tHead, 0.10f);
        tilt = approach(tilt, tTilt, 0.12f);
        earLift = approach(earLift, tEar, 0.12f);
        think = approach(think, tThink, 0.15f);

        // ojos: cerrados al dormir, parpadeo de vez en cuando
        float blink = (t % 3.7f) < 0.12f ? 0.1f : 1f;
        eyesOpen = approach(eyesOpen, state == SLEEP ? 0f : blink, 0.5f);

        float scale = Math.min(w / BW, h / BH);
        c.save();
        c.translate((w - BW * scale) / 2f, (h - BH * scale) / 2f);
        c.scale(scale, scale);
        c.translate(0, 16);

        float lie = 1f - stand;
        float bounce = state == LISTEN ? Math.abs((float) Math.sin(t * 7)) * 1.6f * stand : 0f;
        float breathe = (float) Math.sin(t * (state == SLEEP ? 1.6 : 3.0)) * 0.8f;
        float bodyY = 40f + lie * 12f - bounce;          // parte de arriba del cuerpo
        float ground = 84f;

        float wagSpeed = state == SLEEP ? 0f : state == LISTEN ? 16f : state == SPEAK ? 10f : state == THINK ? 4f : 5f;
        float wagAmp = state == SLEEP ? 0f : state == LISTEN ? 28f : state == SPEAK ? 18f : 10f;
        float wag = (float) Math.sin(t * wagSpeed) * wagAmp;

        // sombra en el piso
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(66, ground + 1, 52, new int[]{Color.argb(110, 0, 0, 0), Color.argb(0, 0, 0, 0)},
                null, Shader.TileMode.CLAMP));
        c.save();
        c.translate(66, ground + 1);
        c.scale(1f, 0.13f);
        c.drawCircle(0, 0, 52, p);
        c.restore();
        p.setShader(null);

        // cola
        c.save();
        c.rotate(-wag - lie * 25f, 22, bodyY + 8);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(5.5f);
        p.setShader(new LinearGradient(22, bodyY + 8, 6, bodyY - 12, FUR, FUR_HI, Shader.TileMode.CLAMP));
        path.reset();
        path.moveTo(26, bodyY + 9);
        path.quadTo(10, bodyY + 4, 7, bodyY - 10);
        c.drawPath(path, p);
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        c.restore();

        // patas de atrás (lejanas, más oscuras)
        float legTop = bodyY + 20f;
        float legLen = 8f + stand * 15f;
        float step = state == LISTEN ? (float) Math.sin(t * 9) * 1.5f : 0f;
        if (stand > 0.05f) {
            leg(c, 40 + step, legTop, legLen, true);
            leg(c, 84 - step, legTop, legLen, true);
        }

        // cuerpo
        fillRound(c, 22, bodyY + breathe * 0.3f, 96, bodyY + 31, 15.5f,
                vertical(bodyY, bodyY + 30, FUR_HI, FUR, FUR_SH));
        // brillo del lomo
        fillOval(c, 32, bodyY + 1.5f, 82, bodyY + 10,
                new RadialGradient(54, bodyY + 5, 26, new int[]{Color.argb(70, 255, 255, 255), Color.argb(0, 255, 255, 255)},
                        null, Shader.TileMode.CLAMP));
        // panza café
        fillOval(c, 34, bodyY + 18, 92, bodyY + 32,
                radial(62, bodyY + 20, 34, TAN_HI, TAN, TAN_SH));
        // pecho café
        fillOval(c, 80, bodyY + 6, 101, bodyY + 31, radial(88, bodyY + 14, 16, TAN_HI, TAN, TAN_SH));

        // patas de adelante (cercanas)
        if (stand > 0.05f) {
            leg(c, 32 - step, legTop, legLen, false);
            leg(c, 76 + step, legTop, legLen, false);
        } else {
            // acostado: patitas delanteras estiradas
            fillOval(c, 90, bodyY + 24, 112, bodyY + 31, radial(98, bodyY + 26, 12, TAN_HI, TAN, TAN_SH));
        }

        // cabeza
        float headCx = 104f + lie * 4f;
        float headCy = bodyY - 8f + (1f - headUp) * 16f + lie * 2f;
        c.save();
        c.rotate(tilt, headCx - 6, headCy + 10);

        // cuello
        fillOval(c, headCx - 20, headCy - 4, headCx + 2, headCy + 24, radial(headCx - 10, headCy + 2, 16, FUR_HI, FUR, FUR_SH));
        // cráneo
        fillOval(c, headCx - 19, headCy - 19, headCx + 17, headCy + 15, radial(headCx - 6, headCy - 11, 27, FUR_HI, FUR, FUR_SH));
        // hocico café
        fillOval(c, headCx + 3, headCy - 3, headCx + 27, headCy + 14, radial(headCx + 12, headCy + 1, 18, TAN_HI, TAN, TAN_SH));
        // cachetes rosados
        fillOval(c, headCx + 4, headCy + 4, headCx + 12, headCy + 9,
                new RadialGradient(headCx + 8, headCy + 6.5f, 4.5f, new int[]{Color.argb(120, 255, 120, 120), Color.argb(0, 255, 120, 120)}, null, Shader.TileMode.CLAMP));
        // ceja café
        fillOval(c, headCx + 4, headCy - 16.5f, headCx + 11, headCy - 12.5f, radial(headCx + 6, headCy - 16, 6, TAN_HI, TAN, TAN_SH));

        // boca
        float open = state == SPEAK ? Math.abs((float) Math.sin(t * 13)) : 0f;
        if (open > 0.08f) {
            fillOval(c, headCx + 10, headCy + 7, headCx + 24, headCy + 9 + open * 8,
                    radial(headCx + 17, headCy + 9, 8, Color.rgb(120, 30, 34), Color.rgb(80, 16, 20), Color.rgb(50, 8, 10)));
            fillOval(c, headCx + 13, headCy + 6 + open * 6, headCx + 21, headCy + 10 + open * 8,
                    radial(headCx + 17, headCy + 8 + open * 6, 5, Color.rgb(255, 150, 160), Color.rgb(230, 100, 120), Color.rgb(180, 60, 80)));
        } else {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.2f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(70, 30, 14));
            path.reset();
            path.moveTo(headCx + 12, headCy + 9);
            path.quadTo(headCx + 18, headCy + 11.5f, headCx + 24, headCy + 8);
            c.drawPath(path, p);
            p.setStyle(Paint.Style.FILL);
        }
        // nariz con brillo
        fillOval(c, headCx + 20, headCy - 4, headCx + 30, headCy + 3.5f,
                radial(headCx + 25, headCy - 2.5f, 6, Color.rgb(110, 100, 100), Color.rgb(25, 20, 20), Color.rgb(5, 4, 4)));
        p.setColor(Color.argb(200, 255, 255, 255));
        c.drawCircle(headCx + 23.5f, headCy - 2.2f, 1.2f, p);

        // ojo
        float ex = headCx + 6, ey = headCy - 6;
        if (eyesOpen > 0.25f) {
            c.save();
            c.translate(ex, ey);
            c.scale(1.3f, 1.3f * eyesOpen);
            p.setColor(Color.rgb(245, 240, 235));
            c.drawCircle(0, 0, 4.4f, p);
            fillOval(c, -3.4f + 0.8f, -3.4f, 3.4f + 0.8f, 3.4f, radial(1.2f, -0.8f, 4f, Color.rgb(120, 70, 40), Color.rgb(60, 32, 18), Color.rgb(20, 10, 6)));
            p.setColor(Color.rgb(8, 6, 5));
            c.drawCircle(1.1f, 0.2f, 2.0f, p);
            p.setColor(Color.WHITE);
            c.drawCircle(2.1f, -1.3f, 1.05f, p);
            c.drawCircle(-0.2f, 1.2f, 0.45f, p);
            c.restore();
        } else {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.4f);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(Color.rgb(10, 8, 6));
            r.set(ex - 5, ey - 3.5f, ex + 5, ey + 3.5f);
            c.drawArc(r, 20, 140, false, p);
            p.setStyle(Paint.Style.FILL);
        }

        // oreja grande (cae sobre el lado de la cabeza)
        float earSwing = (float) Math.sin(t * (state == LISTEN ? 8 : 2.2)) * (state == SLEEP ? 1.5f : 5f);
        float earAngle = 16f - earLift * 28f + earSwing + (1f - headUp) * 10f;
        c.save();
        c.rotate(earAngle, headCx - 7, headCy - 13);
        fillOval(c, headCx - 19, headCy - 16, headCx + 0, headCy + 25,
                new LinearGradient(headCx - 19, 0, headCx + 0, 0, new int[]{EAR_HI, EAR, FUR_SH}, new float[]{0f, 0.5f, 1f},
                        Shader.TileMode.CLAMP));
        // borde de luz de la oreja
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.9f);
        p.setColor(Color.argb(90, 255, 220, 200));
        r.set(headCx - 18.5f, headCy - 15.5f, headCx - 0.5f, headCy + 24.5f);
        c.drawArc(r, 120, 110, false, p);
        p.setStyle(Paint.Style.FILL);
        c.restore();

        c.restore(); // fin de la cabeza

        // globito de "pensando"
        if (think > 0.05f) {
            int a = (int) (230 * think);
            float bx = headCx + 8, by = headCy - 34;
            p.setColor(Color.argb(a, 255, 255, 255));
            c.drawCircle(bx - 10, by + 14, 2.2f, p);
            c.drawCircle(bx - 5, by + 8, 3.2f, p);
            fillRound(c, bx - 2, by - 10, bx + 30, by + 6, 8,
                    new LinearGradient(0, by - 10, 0, by + 6, Color.argb(a, 255, 255, 255), Color.argb(a, 225, 230, 240),
                            Shader.TileMode.CLAMP));
            for (int i = 0; i < 3; i++) {
                float jump = (float) Math.max(0, Math.sin(t * 6 - i * 0.8)) * 2.5f;
                p.setColor(Color.argb(a, 60, 60, 70));
                c.drawCircle(bx + 6 + i * 8, by - 2 - jump, 2.2f, p);
            }
        }

        // Zzz al dormir
        if (state == SLEEP) {
            p.setTextAlign(Paint.Align.LEFT);
            p.setFakeBoldText(true);
            for (int i = 0; i < 3; i++) {
                float ph = ((t * 0.5f) + i / 3f) % 1f;
                p.setColor(Color.argb((int) (220 * (1f - ph)), 255, 255, 255));
                p.setTextSize(7f + i * 2.5f);
                c.drawText("z", headCx + 6 + ph * 16 + i * 5, headCy - 12 - ph * 22 - i * 4, p);
            }
            p.setFakeBoldText(false);
        }

        c.restore();
    }

    /** Una pata: arriba negra, abajo café, con patita. */
    private void leg(Canvas c, float x, float top, float len, boolean far) {
        int hi = far ? FUR : FUR_HI, mid = far ? FUR_SH : FUR, sh = FUR_SH;
        fillRound(c, x - 5.5f, top - 4, x + 5.5f, top + len * 0.55f, 5.5f,
                new LinearGradient(x - 5.5f, 0, x + 5.5f, 0, new int[]{hi, mid, sh}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        int thi = far ? TAN : TAN_HI, tmid = far ? TAN_SH : TAN;
        fillRound(c, x - 5.2f, top + len * 0.35f, x + 5.2f, top + len, 5.2f,
                new LinearGradient(x - 5.2f, 0, x + 5.2f, 0, new int[]{thi, tmid, TAN_SH}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        fillOval(c, x - 6f, top + len - 3.5f, x + 8f, top + len + 3f, radial(x + 1, top + len - 2.5f, 8, thi, tmid, TAN_SH));
    }
}
