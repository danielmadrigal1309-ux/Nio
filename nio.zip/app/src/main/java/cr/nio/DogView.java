package cr.nio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

import java.io.File;

/**
 * Muestra a Beto animado. Si escogiste imágenes (dormido / despierto) las usa y las anima;
 * si no, usa el perrito dibujado.
 */
public class DogView extends View {

    public static final int SLEEP = DogPainter.SLEEP, IDLE = DogPainter.IDLE, LISTEN = DogPainter.LISTEN,
            THINK = DogPainter.THINK, SPEAK = DogPainter.SPEAK;

    /** Sube cada vez que cambian las imágenes, para que todas las vistas las recarguen. */
    public static volatile int imagesVersion = 0;

    private final DogPainter painter = new DogPainter();
    private final long t0 = System.currentTimeMillis();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF r = new RectF();
    private int state = IDLE;

    private Bitmap awake, asleep;
    private int loadedVersion = -1;
    private float awakeMix = 1f;   // 0 = imagen dormido, 1 = imagen despierto
    private float tiltNow = 0f;

    public DogView(Context c) {
        super(c);
        setLayerType(LAYER_TYPE_HARDWARE, null);
    }

    public void setState(int s) { state = s; invalidate(); }

    public int getState() { return state; }

    public static File awakeFile(Context c) { return new File(c.getFilesDir(), "beto_despierto.png"); }

    public static File asleepFile(Context c) { return new File(c.getFilesDir(), "beto_dormido.png"); }

    private void loadImages() {
        loadedVersion = imagesVersion;
        awake = load(awakeFile(getContext()));
        asleep = load(asleepFile(getContext()));
    }

    private static Bitmap load(File f) {
        try { return f.exists() ? BitmapFactory.decodeFile(f.getAbsolutePath()) : null; }
        catch (Throwable e) { return null; }
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        if (w < 10 || h < 10) { postInvalidateOnAnimation(); return; }
        if (loadedVersion != imagesVersion) loadImages();
        float t = (System.currentTimeMillis() - t0) / 1000f;
        if (awake == null && asleep == null) {
            painter.draw(c, w, h, state, t);
        } else {
            drawImage(c, w, h, t);
        }
        postInvalidateOnAnimation();
    }

    /** Anima la imagen escogida: respira, brinca, habla y ladea la cabeza. */
    private void drawImage(Canvas c, float w, float h, float t) {
        awakeMix += ((state == SLEEP ? 0f : 1f) - awakeMix) * 0.12f;

        float sx = 1f, sy = 1f, dy = 0f, rot = 0f;
        switch (state) {
            case SLEEP:
                sy = 1f + 0.025f * (float) Math.sin(t * 1.6);
                break;
            case IDLE:
                dy = -0.015f * (float) Math.sin(t * 2.2);
                sy = 1f + 0.012f * (float) Math.sin(t * 2.2);
                break;
            case LISTEN:
                float b = Math.abs((float) Math.sin(t * 6.5));
                dy = -0.07f * b;
                sy = 1f + 0.05f * b;
                sx = 1f - 0.03f * b;
                rot = 4f * (float) Math.sin(t * 3.2);
                break;
            case THINK:
                rot = 9f;
                dy = -0.01f * (float) Math.sin(t * 2);
                break;
            case SPEAK:
                float m = Math.abs((float) Math.sin(t * 12));
                sy = 1f + 0.045f * m;
                sx = 1f - 0.025f * m;
                rot = 2.5f * (float) Math.sin(t * 5);
                break;
        }
        tiltNow += (rot - tiltNow) * 0.15f;

        float pad = 0.08f;
        float boxW = w * (1 - 2 * pad), boxH = h * 0.82f;
        float ground = h * 0.94f;

        // sombra
        float shW = boxW * 0.42f * (1f + dy * 2f);
        p.setShader(new RadialGradient(w / 2, ground, shW, new int[]{Color.argb(90, 0, 0, 0), Color.argb(0, 0, 0, 0)},
                null, Shader.TileMode.CLAMP));
        c.save();
        c.translate(w / 2, ground);
        c.scale(1f, 0.16f);
        c.drawCircle(0, 0, shW, p);
        c.restore();
        p.setShader(null);

        c.save();
        c.translate(w / 2, ground + dy * h);
        c.rotate(tiltNow, 0, -boxH * 0.3f);
        c.scale(sx, sy);
        drawFit(c, asleep != null ? asleep : awake, boxW, boxH, asleep != null ? (int) (255 * (1f - awakeMix)) : 255);
        if (awake != null && asleep != null) drawFit(c, awake, boxW, boxH, (int) (255 * awakeMix));
        c.restore();

        // Zzz y globito de pensar
        p.setFakeBoldText(true);
        p.setTextAlign(Paint.Align.LEFT);
        if (state == SLEEP) {
            for (int i = 0; i < 3; i++) {
                float ph = ((t * 0.5f) + i / 3f) % 1f;
                p.setColor(Color.argb((int) (230 * (1f - ph)), 255, 255, 255));
                p.setTextSize(h * (0.07f + i * 0.025f));
                c.drawText("z", w * (0.62f + ph * 0.15f + i * 0.04f), h * (0.32f - ph * 0.22f - i * 0.03f), p);
            }
        }
        if (state == THINK) {
            float bx = w * 0.70f, by = h * 0.10f, rr = h * 0.035f;
            p.setColor(Color.argb(235, 255, 255, 255));
            r.set(bx - rr * 3.6f, by - rr * 1.6f, bx + rr * 3.6f, by + rr * 1.6f);
            c.drawRoundRect(r, rr * 1.6f, rr * 1.6f, p);
            c.drawCircle(bx - rr * 3.2f, by + rr * 2.6f, rr * 0.6f, p);
            for (int i = 0; i < 3; i++) {
                float jump = (float) Math.max(0, Math.sin(t * 6 - i * 0.8)) * rr * 0.6f;
                p.setColor(Color.argb(235, 60, 60, 70));
                c.drawCircle(bx - rr * 2 + i * rr * 2, by - jump, rr * 0.55f, p);
            }
        }
        p.setFakeBoldText(false);
    }

    /** Dibuja la imagen apoyada en el piso (0,0 = centro abajo), del tamaño que quepa. */
    private void drawFit(Canvas c, Bitmap b, float boxW, float boxH, int alpha) {
        if (b == null || alpha <= 2) return;
        float s = Math.min(boxW / b.getWidth(), boxH / b.getHeight());
        float bw = b.getWidth() * s, bh = b.getHeight() * s;
        r.set(-bw / 2, -bh, bw / 2, 0);
        p.setAlpha(alpha);
        c.drawBitmap(b, null, r, p);
        p.setAlpha(255);
    }
}
