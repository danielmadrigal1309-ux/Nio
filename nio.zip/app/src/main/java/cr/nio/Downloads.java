package cr.nio;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.webkit.URLUtil;

/** Descarga archivos a la carpeta Descargas del teléfono. */
public class Downloads {

    public static String start(Context c, String url) {
        try {
            url = url.trim().replaceAll("[)\\],.;]+$", "");
            if (!url.startsWith("http")) url = "https://" + url;
            Uri u = Uri.parse(url);
            String name = URLUtil.guessFileName(url, null, null);
            DownloadManager.Request r = new DownloadManager.Request(u)
                    .setTitle(name)
                    .setDescription("Descargado por Beto")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) c.getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            return "Descargando " + name + ". Te aviso en las notificaciones cuando termine; queda en Descargas.";
        } catch (Exception e) {
            return "No pude descargar ese enlace.";
        }
    }
}
