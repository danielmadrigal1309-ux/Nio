package cr.nio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Guarda la imagen que escogiste para Beto y, si tiene fondo liso, se lo quita. */
public class ImageTool {

    public static boolean importImage(Context c, Uri uri, File out, boolean removeBg) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = c.getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 900) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap b;
            try (InputStream in = c.getContentResolver().openInputStream(uri)) { b = BitmapFactory.decodeStream(in, null, o2); }
            if (b == null) return false;
            Bitmap m = b.copy(Bitmap.Config.ARGB_8888, true);
            if (removeBg) removeBackground(m);
            m = crop(m);
            try (FileOutputStream fo = new FileOutputStream(out)) { m.compress(Bitmap.CompressFormat.PNG, 100, fo); }
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    /** Quita el fondo liso empezando por los bordes (como el balde de pintura). */
    static void removeBackground(Bitmap m) {
        int w = m.getWidth(), h = m.getHeight();
        int[] px = new int[w * h];
        m.getPixels(px, 0, w, 0, 0, w, h);
        // si ya trae transparencia en las esquinas, no se toca
        if (Color.alpha(px[0]) < 40 && Color.alpha(px[w - 1]) < 40) return;
        int bg = px[0];
        int tol = 48;
        boolean[] seen = new boolean[w * h];
        int[] stack = new int[w * h];
        int sp = 0;
        for (int x = 0; x < w; x++) { stack[sp++] = x; stack[sp++] = (h - 1) * w + x; }
        for (int y = 0; y < h; y++) { stack[sp++] = y * w; stack[sp++] = y * w + w - 1; }
        while (sp > 0) {
            int i = stack[--sp];
            if (i < 0 || i >= px.length || seen[i]) continue;
            seen[i] = true;
            int c = px[i];
            if (dist(c, bg) > tol) continue;
            px[i] = 0;
            int x = i % w;
            if (x > 0 && sp < stack.length) stack[sp++] = i - 1;
            if (x < w - 1 && sp < stack.length) stack[sp++] = i + 1;
            if (i - w >= 0 && sp < stack.length) stack[sp++] = i - w;
            if (i + w < px.length && sp < stack.length) stack[sp++] = i + w;
        }
        // suaviza el borde: pixeles casi del color del fondo pegados a lo transparente quedan semitransparentes
        for (int y = 1; y < h - 1; y++) {
            for (int x = 1; x < w - 1; x++) {
                int i = y * w + x;
                if (px[i] == 0) continue;
                boolean edge = px[i - 1] == 0 || px[i + 1] == 0 || px[i - w] == 0 || px[i + w] == 0;
                if (edge) {
                    int d = dist(px[i], bg);
                    int a = Math.min(255, Math.max(80, d * 3));
                    px[i] = (a << 24) | (px[i] & 0xFFFFFF);
                }
            }
        }
        m.setPixels(px, 0, w, 0, 0, w, h);
    }

    private static int dist(int a, int b) {
        return Math.abs(Color.red(a) - Color.red(b)) + Math.abs(Color.green(a) - Color.green(b))
                + Math.abs(Color.blue(a) - Color.blue(b));
    }

    /** Recorta lo transparente que sobra alrededor. */
    static Bitmap crop(Bitmap m) {
        int w = m.getWidth(), h = m.getHeight();
        int[] px = new int[w * h];
        m.getPixels(px, 0, w, 0, 0, w, h);
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if ((px[y * w + x] >>> 24) > 20) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        if (maxX < minX || maxY < minY) return m;
        return Bitmap.createBitmap(m, minX, minY, maxX - minX + 1, maxY - minY + 1);
    }
}
