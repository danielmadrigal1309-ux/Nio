package cr.nio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements Brain.Out {

    private static final int BG = Color.parseColor("#050B14");
    private static final int CYAN = Color.parseColor("#22D3EE");
    private static final int INK = Color.parseColor("#E6FBFF");
    private static final int DIM = Color.parseColor("#7FA6B5");

    private ReactorView reactor;
    private TextView status;
    private LinearLayout chat;
    private ScrollView scroll;
    private EditText input;
    private Button wakeBtn;

    private Brain brain;
    private TextToSpeech tts;
    private SpeechRecognizer sr;
    private boolean listening = false;
    private int uid = 0;
    private float dp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dp = getResources().getDisplayMetrics().density;
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        brain = new Brain(this, this);
        buildUi();

        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("es", "CR"));
                if (r < 0) tts.setLanguage(new Locale("es"));
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { runOnUiThread(() -> reactor.setState(ReactorView.SPEAK)); }
                    @Override public void onDone(String id) { runOnUiThread(() -> { if (!tts.isSpeaking()) idle(); }); }
                    @Override public void onError(String id) { runOnUiThread(MainActivity.this::idle); }
                });
            }
        });

        askPermissions();
        SharedPreferences p = getSharedPreferences(Brain.PREFS, MODE_PRIVATE);
        if (p.getString("key", "").isEmpty()) {
            addBubble("Nio", "Hola, soy Nio. Para conversar conmigo pon tu clave de Gemini en Ajustes. "
                    + "Los comandos (abrir apps, llamar, alarmas, linterna…) ya funcionan sin clave.", false);
        } else {
            addBubble("Nio", "A sus órdenes. Toca el núcleo y háblame, o activa el modo escucha y di \"Nio\".", false);
        }
        handleAssist(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handleAssist(i);
    }

    private void handleAssist(Intent i) {
        if (i != null && Intent.ACTION_ASSIST.equals(i.getAction())) {
            reactor.postDelayed(this::startListening, 400);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshWakeBtn();
    }

    // ---------- interfaz ----------

    private GradientDrawable round(int fill, int stroke, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius * dp);
        if (stroke != 0) g.setStroke((int) (1.5f * dp), stroke);
        return g;
    }

    private Button button(String text, boolean primary) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setAllCaps(false);
        bt.setTextSize(15);
        bt.setTextColor(primary ? BG : INK);
        bt.setTypeface(Typeface.DEFAULT_BOLD);
        bt.setBackground(round(primary ? CYAN : Color.parseColor("#0B1A26"), primary ? 0 : Color.parseColor("#1E4A5C"), 14));
        bt.setMinHeight((int) (48 * dp));
        bt.setPadding((int) (16 * dp), 0, (int) (16 * dp), 0);
        return bt;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        int pad = (int) (16 * dp);
        root.setPadding(pad, (int) (28 * dp), pad, pad);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("NIO");
        title.setTextColor(INK);
        title.setTextSize(26);
        title.setLetterSpacing(0.25f);
        title.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button settings = button("Ajustes", false);
        settings.setOnClickListener(v -> showSettings());
        top.addView(settings);
        root.addView(top);

        reactor = new ReactorView(this);
        reactor.setOnClickListener(v -> {
            if (listening) stopListeningMic(); else startListening();
        });
        int size = (int) (230 * dp);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(size, size);
        rp.gravity = Gravity.CENTER_HORIZONTAL;
        rp.topMargin = (int) (8 * dp);
        root.addView(reactor, rp);

        status = new TextView(this);
        status.setText("Toca el núcleo para hablar");
        status.setTextColor(DIM);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        wakeBtn = button("", false);
        wakeBtn.setOnClickListener(v -> toggleWake());
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, -2);
        wp.topMargin = (int) (10 * dp);
        root.addView(wakeBtn, wp);

        scroll = new ScrollView(this);
        chat = new LinearLayout(this);
        chat.setOrientation(LinearLayout.VERTICAL);
        chat.setPadding(0, (int) (8 * dp), 0, (int) (8 * dp));
        scroll.addView(chat);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1);
        sp.topMargin = (int) (10 * dp);
        root.addView(scroll, sp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setHint("Escríbele a Nio…");
        input.setHintTextColor(DIM);
        input.setTextColor(INK);
        input.setTextSize(16);
        input.setSingleLine(true);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setBackground(round(Color.parseColor("#0B1A26"), Color.parseColor("#1E4A5C"), 14));
        input.setPadding((int) (14 * dp), (int) (10 * dp), (int) (14 * dp), (int) (10 * dp));
        input.setOnEditorActionListener((v, id, e) -> { send(); return true; });
        bottom.addView(input, new LinearLayout.LayoutParams(0, (int) (48 * dp), 1));
        Button sendBtn = button("Enviar", true);
        sendBtn.setOnClickListener(v -> send());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, (int) (48 * dp));
        bp.leftMargin = (int) (8 * dp);
        bottom.addView(sendBtn, bp);
        root.addView(bottom);

        setContentView(root);
    }

    private void addBubble(String who, String text, boolean mine) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(16);
        tv.setTextColor(mine ? BG : INK);
        tv.setLineSpacing(0, 1.15f);
        int p = (int) (12 * dp);
        tv.setPadding(p, (int) (9 * dp), p, (int) (9 * dp));
        tv.setBackground(round(mine ? Color.parseColor("#7DE3F4") : Color.parseColor("#0D2230"),
                mine ? 0 : Color.parseColor("#17394A"), 16));
        tv.setTextIsSelectable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.gravity = mine ? Gravity.END : Gravity.START;
        lp.topMargin = (int) (6 * dp);
        if (mine) lp.leftMargin = (int) (48 * dp); else lp.rightMargin = (int) (48 * dp);
        chat.addView(tv, lp);
        while (chat.getChildCount() > 80) chat.removeViewAt(0);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void send() {
        String t = input.getText().toString().trim();
        if (t.isEmpty()) return;
        input.setText("");
        brain.handle(t);
    }

    private void idle() {
        if (!listening) {
            reactor.setState(ReactorView.IDLE);
            status.setText(NioService.running ? "Modo escucha activo: di \"Nio\"" : "Toca el núcleo para hablar");
        }
    }

    // ---------- voz ----------

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            askPermissions();
            return;
        }
        if (NioService.running) {
            Toast.makeText(this, "El modo escucha está activo: solo di \"Nio\" y tu orden.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addBubble("Nio", "Este teléfono no tiene reconocimiento de voz. Instala o actualiza la app de Google.", false);
            return;
        }
        if (tts != null) tts.stop();
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) { status.setText("Te escucho…"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float v) { }
                @Override public void onBufferReceived(byte[] b) { }
                @Override public void onEndOfSpeech() { status.setText("Procesando…"); }
                @Override public void onEvent(int t, Bundle b) { }
                @Override public void onPartialResults(Bundle b) {
                    ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty() && !r.get(0).isEmpty()) status.setText(r.get(0));
                }
                @Override public void onError(int e) {
                    listening = false;
                    idle();
                    if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                        status.setText("No te escuché bien. Toca y prueba otra vez.");
                    else if (e == SpeechRecognizer.ERROR_NETWORK || e == SpeechRecognizer.ERROR_NETWORK_TIMEOUT)
                        status.setText("Sin conexión para reconocer la voz.");
                }
                @Override public void onResults(Bundle b) {
                    listening = false;
                    idle();
                    ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty()) {
                        String txt = r.get(0);
                        String n = Brain.norm(txt);
                        if (n.startsWith("nio ")) txt = n.substring(4);
                        brain.handle(txt);
                    }
                }
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CR");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        listening = true;
        reactor.setState(ReactorView.LISTEN);
        sr.startListening(i);
    }

    private void stopListeningMic() {
        if (sr != null) sr.stopListening();
        listening = false;
        idle();
    }

    private void toggleWake() {
        if (NioService.running) {
            stopService(new Intent(this, NioService.class));
            NioService.running = false;
        } else {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                askPermissions();
                return;
            }
            if (sr != null) { sr.destroy(); sr = null; }
            listening = false;
            startForegroundService(new Intent(this, NioService.class));
            NioService.running = true;
            if (!Settings.canDrawOverlays(this)) {
                addBubble("Nio", "Para que pueda abrir apps y llamar mientras estoy en segundo plano, "
                        + "dame el permiso \"Mostrar sobre otras apps\" en Ajustes.", false);
            }
        }
        refreshWakeBtn();
        idle();
    }

    private void refreshWakeBtn() {
        if (wakeBtn == null) return;
        boolean on = NioService.running;
        wakeBtn.setText(on ? "Modo escucha: ACTIVO (toca para apagar)" : "Activar modo escucha: \"Nio…\"");
        wakeBtn.setTextColor(on ? BG : INK);
        wakeBtn.setBackground(round(on ? CYAN : Color.parseColor("#0B1A26"), on ? 0 : Color.parseColor("#1E4A5C"), 14));
        idle();
    }

    // ---------- Brain.Out ----------

    @Override
    public void say(String text) {
        if (tts == null || text == null || text.isEmpty()) return;
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "m" + (uid++));
    }

    @Override
    public void log(String who, String text) {
        addBubble(who, text, "Tú".equals(who));
    }

    @Override
    public void thinking(boolean on) {
        if (on) { reactor.setState(ReactorView.THINK); status.setText("Pensando…"); }
        else idle();
    }

    @Override
    public void stopListening() {
        if (NioService.running) {
            stopService(new Intent(this, NioService.class));
            NioService.running = false;
            refreshWakeBtn();
        } else {
            stopListeningMic();
        }
    }

    // ---------- permisos y ajustes ----------

    private void askPermissions() {
        List<String> need = new ArrayList<>();
        String[] all = Build.VERSION.SDK_INT >= 33
                ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE, Manifest.permission.POST_NOTIFICATIONS}
                : new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE};
        for (String p : all) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 5);
    }

    private EditText field(String hint, String value, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setTextSize(16);
        e.setSingleLine(true);
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        return e;
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13);
        t.setPadding(0, (int) (12 * dp), 0, 0);
        return t;
    }

    private void showSettings() {
        final SharedPreferences p = getSharedPreferences(Brain.PREFS, MODE_PRIVATE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * dp);
        box.setPadding(pad, (int) (8 * dp), pad, 0);

        final EditText name = field("Tu nombre", p.getString("name", ""), false);
        final EditText key = field("Pega aquí tu clave de Gemini", p.getString("key", ""), true);
        final EditText model = field(Brain.DEFAULT_MODEL, p.getString("model", Brain.DEFAULT_MODEL), false);

        box.addView(label("¿Cómo te llamo?"));
        box.addView(name);
        box.addView(label("Clave de Gemini (de aistudio.google.com)"));
        box.addView(key);
        box.addView(label("Modelo de Gemini"));
        box.addView(model);

        Button overlay = new Button(this);
        overlay.setAllCaps(false);
        overlay.setText(Settings.canDrawOverlays(this) ? "Permiso para segundo plano: listo"
                : "Dar permiso para abrir apps en segundo plano");
        overlay.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));
        box.addView(overlay);

        Button perms = new Button(this);
        perms.setAllCaps(false);
        perms.setText("Revisar permisos (micrófono, contactos, llamadas)");
        perms.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        box.addView(perms);

        Button forget = new Button(this);
        forget.setAllCaps(false);
        forget.setText("Borrar todo lo que Nio aprendió");
        forget.setOnClickListener(v -> {
            p.edit().remove("routines").remove("facts").apply();
            Toast.makeText(this, "Nio olvidó sus rutinas y recuerdos.", Toast.LENGTH_SHORT).show();
        });
        box.addView(forget);

        ScrollView sv = new ScrollView(this);
        sv.addView(box);

        new AlertDialog.Builder(this)
                .setTitle("Ajustes de Nio")
                .setView(sv)
                .setPositiveButton("Guardar", (d, w) -> {
                    p.edit().putString("name", name.getText().toString().trim())
                            .putString("key", key.getText().toString().trim())
                            .putString("model", model.getText().toString().trim())
                            .apply();
                    Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        if (sr != null) sr.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
