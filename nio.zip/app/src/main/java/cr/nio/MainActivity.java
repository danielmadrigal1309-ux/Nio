package cr.nio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity implements Brain.Out {

    // Colores tipo vidrio: se calculan según el modo claro/oscuro y los colores del sistema
    private boolean dark;
    private int SCRIM, ACCENT, ON_ACCENT, INK, DIM, GLASS, GLASS_LINE, MINE;

    private static int alpha(int c, int a) {
        return Color.argb(a, Color.red(c), Color.green(c), Color.blue(c));
    }

    private void computeColors() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        dark = mode == Configuration.UI_MODE_NIGHT_YES;
        if (Build.VERSION.SDK_INT >= 31) {
            ACCENT = getColor(dark ? android.R.color.system_accent1_200 : android.R.color.system_accent1_600);
            ON_ACCENT = getColor(dark ? android.R.color.system_accent1_900 : android.R.color.system_accent1_0);
        } else {
            ACCENT = dark ? Color.parseColor("#E8EAED") : Color.parseColor("#3C4043");
            ON_ACCENT = dark ? Color.parseColor("#202124") : Color.WHITE;
        }
        SCRIM = dark ? Color.argb(120, 0, 0, 0) : Color.argb(90, 255, 255, 255);
        INK = dark ? Color.argb(240, 255, 255, 255) : Color.argb(230, 20, 20, 24);
        DIM = dark ? Color.argb(170, 255, 255, 255) : Color.argb(160, 20, 20, 24);
        GLASS = dark ? Color.argb(46, 255, 255, 255) : Color.argb(110, 255, 255, 255);
        GLASS_LINE = dark ? Color.argb(60, 255, 255, 255) : Color.argb(150, 255, 255, 255);
        MINE = alpha(ACCENT, 215);
    }

    private int dialogTheme() {
        return dark ? android.R.style.Theme_DeviceDefault_Dialog_Alert
                : android.R.style.Theme_DeviceDefault_Light_Dialog_Alert;
    }

    private ReactorView reactor;
    private TextView status;
    private LinearLayout chat;
    private ScrollView scroll;
    private EditText input;
    private Button wakeBtn;

    private Brain brain;
    private TextToSpeech tts;
    private SpeechRecognizer sr;
    private boolean listening = false;
    private int uid = 0;
    private float dp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        dp = getResources().getDisplayMetrics().density;
        computeColors();
        // se ve el fondo de pantalla del teléfono detrás de Nio
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (!dark) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    | (Build.VERSION.SDK_INT >= 26 ? View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0));
        }
        brain = new Brain(this, this);
        buildUi();

        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("es", "CR"));
                if (r < 0) tts.setLanguage(new Locale("es"));
                Voz.apply(this, tts);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { runOnUiThread(() -> reactor.setState(ReactorView.SPEAK)); }
                    @Override public void onDone(String id) { runOnUiThread(() -> { if (!tts.isSpeaking()) idle(); }); }
                    @Override public void onError(String id) { runOnUiThread(MainActivity.this::idle); }
                });
            }
        });

        askPermissions();
        SharedPreferences p = getSharedPreferences(Brain.PREFS, MODE_PRIVATE);
        if (p.getString("key", "").isEmpty()) {
            addBubble("Nio", "Hola, soy Nio. Para conversar conmigo pon tu clave de Gemini en Ajustes. "
                    + "Los comandos (abrir apps, llamar, alarmas, linterna…) ya funcionan sin clave.", false);
        } else {
            addBubble("Nio", "A sus órdenes. Toca el núcleo y háblame, o activa el modo escucha y di \"Nio\".", false);
        }
        handleAssist(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handleAssist(i);
    }

    private void handleAssist(Intent i) {
        if (i != null && Intent.ACTION_ASSIST.equals(i.getAction())) {
            reactor.postDelayed(this::startListening, 400);
        }
    }

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (NioService.running && !listening && reactor.getState() != ReactorView.THINK
                    && !NioService.debug.isEmpty()) {
                status.setText(NioService.debug);
            }
            reactor.postDelayed(this, 700);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        refreshWakeBtn();
        reactor.removeCallbacks(poll);
        reactor.postDelayed(poll, 700);
    }

    @Override
    protected void onPause() {
        reactor.removeCallbacks(poll);
        super.onPause();
    }

    // ---------- interfaz ----------

    private GradientDrawable round(int fill, int stroke, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius * dp);
        if (stroke != 0) g.setStroke((int) (1.5f * dp), stroke);
        return g;
    }

    private Button button(String text, boolean primary) {
        Button bt = new Button(this);
        bt.setText(text);
        bt.setAllCaps(false);
        bt.setTextSize(15);
        bt.setTextColor(primary ? ON_ACCENT : INK);
        bt.setTypeface(Typeface.DEFAULT_BOLD);
        bt.setBackground(round(primary ? ACCENT : GLASS, primary ? 0 : GLASS_LINE, 22));
        bt.setMinHeight((int) (48 * dp));
        bt.setPadding((int) (16 * dp), 0, (int) (16 * dp), 0);
        return bt;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(SCRIM);
        int pad = (int) (16 * dp);
        root.setPadding(pad, (int) (28 * dp), pad, pad);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Nio");
        title.setTextColor(INK);
        title.setTextSize(28);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button settings = button("Ajustes", false);
        settings.setOnClickListener(v -> showSettings());
        top.addView(settings);
        root.addView(top);

        reactor = new ReactorView(this);
        reactor.setTint(ACCENT, dark);
        reactor.setOnClickListener(v -> {
            if (listening) stopListeningMic(); else startListening();
        });
        int size = (int) (230 * dp);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(size, size);
        rp.gravity = Gravity.CENTER_HORIZONTAL;
        rp.topMargin = (int) (8 * dp);
        root.addView(reactor, rp);

        status = new TextView(this);
        status.setText("Toca el núcleo para hablar");
        status.setTextColor(DIM);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        wakeBtn = button("", false);
        wakeBtn.setOnClickListener(v -> toggleWake());
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, -2);
        wp.topMargin = (int) (10 * dp);
        root.addView(wakeBtn, wp);

        scroll = new ScrollView(this);
        chat = new LinearLayout(this);
        chat.setOrientation(LinearLayout.VERTICAL);
        chat.setPadding(0, (int) (8 * dp), 0, (int) (8 * dp));
        scroll.addView(chat);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1);
        sp.topMargin = (int) (10 * dp);
        root.addView(scroll, sp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setHint("Escríbele a Nio…");
        input.setHintTextColor(DIM);
        input.setTextColor(INK);
        input.setTextSize(16);
        input.setSingleLine(true);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setBackground(round(GLASS, GLASS_LINE, 24));
        input.setPadding((int) (14 * dp), (int) (10 * dp), (int) (14 * dp), (int) (10 * dp));
        input.setOnEditorActionListener((v, id, e) -> { send(); return true; });
        bottom.addView(input, new LinearLayout.LayoutParams(0, (int) (48 * dp), 1));
        Button sendBtn = button("Enviar", true);
        sendBtn.setOnClickListener(v -> send());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, (int) (48 * dp));
        bp.leftMargin = (int) (8 * dp);
        bottom.addView(sendBtn, bp);
        root.addView(bottom);

        setContentView(root);
    }

    private void addBubble(String who, String text, boolean mine) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(16);
        tv.setTextColor(mine ? ON_ACCENT : INK);
        tv.setLineSpacing(0, 1.15f);
        int p = (int) (12 * dp);
        tv.setPadding(p, (int) (9 * dp), p, (int) (9 * dp));
        tv.setBackground(round(mine ? MINE : GLASS, mine ? 0 : GLASS_LINE, 20));
        tv.setTextIsSelectable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.gravity = mine ? Gravity.END : Gravity.START;
        lp.topMargin = (int) (6 * dp);
        if (mine) lp.leftMargin = (int) (48 * dp); else lp.rightMargin = (int) (48 * dp);
        chat.addView(tv, lp);
        while (chat.getChildCount() > 80) chat.removeViewAt(0);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void send() {
        String t = input.getText().toString().trim();
        if (t.isEmpty()) return;
        input.setText("");
        brain.handle(t);
    }

    private void idle() {
        if (!listening) {
            reactor.setState(ReactorView.IDLE);
            status.setText(NioService.running ? "Modo escucha activo: di \"Nio\"" : "Toca el núcleo para hablar");
        }
    }

    // ---------- voz ----------

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            askPermissions();
            return;
        }
        if (NioService.running) {
            Toast.makeText(this, "El modo escucha está activo: solo di \"Nio\" y tu orden.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addBubble("Nio", "Este teléfono no tiene reconocimiento de voz. Instala o actualiza la app de Google.", false);
            return;
        }
        if (tts != null) tts.stop();
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) { status.setText("Te escucho…"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float v) { }
                @Override public void onBufferReceived(byte[] b) { }
                @Override public void onEndOfSpeech() { status.setText("Procesando…"); }
                @Override public void onEvent(int t, Bundle b) { }
                @Override public void onPartialResults(Bundle b) {
                    ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty() && !r.get(0).isEmpty()) status.setText(r.get(0));
                }
                @Override public void onError(int e) {
                    listening = false;
                    idle();
                    if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                        status.setText("No te escuché bien. Toca y prueba otra vez.");
                    else if (e == SpeechRecognizer.ERROR_NETWORK || e == SpeechRecognizer.ERROR_NETWORK_TIMEOUT)
                        status.setText("Sin conexión para reconocer la voz.");
                }
                @Override public void onResults(Bundle b) {
                    listening = false;
                    idle();
                    ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty()) {
                        String txt = r.get(0);
                        String n = Brain.norm(txt);
                        if (n.startsWith("nio ")) txt = n.substring(4);
                        brain.handle(txt);
                    }
                }
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CR");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        listening = true;
        reactor.setState(ReactorView.LISTEN);
        sr.startListening(i);
    }

    private void stopListeningMic() {
        if (sr != null) sr.stopListening();
        listening = false;
        idle();
    }

    private void toggleWake() {
        if (NioService.running) {
            stopService(new Intent(this, NioService.class));
            NioService.running = false;
        } else {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                askPermissions();
                return;
            }
            if (sr != null) { sr.destroy(); sr = null; }
            listening = false;
            startForegroundService(new Intent(this, NioService.class));
            NioService.running = true;
            if (!Settings.canDrawOverlays(this)) {
                addBubble("Nio", "Para que pueda abrir apps y llamar mientras estoy en segundo plano, "
                        + "dame el permiso \"Mostrar sobre otras apps\" en Ajustes.", false);
            }
        }
        refreshWakeBtn();
        idle();
    }

    private void refreshWakeBtn() {
        if (wakeBtn == null) return;
        boolean on = NioService.running;
        wakeBtn.setText(on ? "Escuchando \"Nio\" · toca para apagar" : "Activar modo escucha");
        wakeBtn.setTextColor(on ? ON_ACCENT : INK);
        wakeBtn.setBackground(round(on ? ACCENT : GLASS, on ? 0 : GLASS_LINE, 22));
        idle();
    }

    // ---------- Brain.Out ----------

    @Override
    public void say(String text) {
        if (tts == null || text == null || text.isEmpty()) return;
        try {
            ((AudioManager) getSystemService(AUDIO_SERVICE))
                    .adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0);
        } catch (Exception ignored) { }
        Voz.apply(this, tts);
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "m" + (uid++));
    }

    @Override
    public void log(String who, String text) {
        addBubble(who, text, "Tú".equals(who));
    }

    @Override
    public void thinking(boolean on) {
        if (on) { reactor.setState(ReactorView.THINK); status.setText("Pensando…"); }
        else idle();
    }

    @Override
    public void stopListening() {
        if (NioService.running) {
            stopService(new Intent(this, NioService.class));
            NioService.running = false;
            refreshWakeBtn();
        } else {
            stopListeningMic();
        }
    }

    // ---------- permisos y ajustes ----------

    private void askPermissions() {
        List<String> need = new ArrayList<>();
        String[] all = Build.VERSION.SDK_INT >= 33
                ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE, Manifest.permission.POST_NOTIFICATIONS}
                : new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE};
        for (String p : all) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 5);
    }

    private EditText field(String hint, String value, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setTextSize(16);
        e.setSingleLine(true);
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        return e;
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13);
        t.setPadding(0, (int) (12 * dp), 0, 0);
        return t;
    }

    private void showSettings() {
        final SharedPreferences p = getSharedPreferences(Brain.PREFS, MODE_PRIVATE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * dp);
        box.setPadding(pad, (int) (8 * dp), pad, 0);

        final EditText name = field("Tu nombre", p.getString("name", ""), false);
        final EditText key = field("Pega aquí tu clave de Gemini", p.getString("key", ""), true);
        final EditText model = field(Brain.DEFAULT_MODEL, p.getString("model", Brain.DEFAULT_MODEL), false);

        box.addView(label("¿Cómo te llamo?"));
        box.addView(name);
        box.addView(label("Clave de Gemini (de aistudio.google.com)"));
        box.addView(key);
        box.addView(label("Modelo de Gemini"));
        box.addView(model);

        // ----- voz -----
        box.addView(label("Voz de Nio"));
        final String[] chosen = {p.getString("voice", "")};
        final Button voiceBtn = new Button(this);
        voiceBtn.setAllCaps(false);
        voiceBtn.setText("Escoger voz (toca cada una para oírla)");
        voiceBtn.setOnClickListener(v -> pickVoice(chosen));
        box.addView(voiceBtn);

        final TextView rateLbl = label("");
        final SeekBar rate = new SeekBar(this);
        rate.setMax(100);
        rate.setProgress(Math.round((p.getFloat("rate", 1f) - 0.5f) * 100));
        final TextView pitchLbl = label("");
        final SeekBar pitch = new SeekBar(this);
        pitch.setMax(100);
        pitch.setProgress(Math.round((p.getFloat("pitch", 1f) - 0.5f) * 100));
        SeekBar.OnSeekBarChangeListener upd = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int v, boolean u) {
                rateLbl.setText(String.format(Locale.ROOT, "Velocidad: %.2f", 0.5f + rate.getProgress() / 100f));
                pitchLbl.setText(String.format(Locale.ROOT, "Tono (más bajo = más grave): %.2f", 0.5f + pitch.getProgress() / 100f));
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                if (tts != null) {
                    tts.setSpeechRate(0.5f + rate.getProgress() / 100f);
                    tts.setPitch(0.5f + pitch.getProgress() / 100f);
                    tts.speak("Así sueno ahora, señor.", TextToSpeech.QUEUE_FLUSH, null, "prueba");
                }
            }
        };
        rate.setOnSeekBarChangeListener(upd);
        pitch.setOnSeekBarChangeListener(upd);
        upd.onProgressChanged(rate, 0, false);
        box.addView(rateLbl);
        box.addView(rate);
        box.addView(pitchLbl);
        box.addView(pitch);

        Button jarvis = new Button(this);
        jarvis.setAllCaps(false);
        jarvis.setText("Estilo Jarvis (grave y pausado)");
        jarvis.setOnClickListener(v -> {
            rate.setProgress(Math.round((Voz.JARVIS_RATE - 0.5f) * 100));
            pitch.setProgress(Math.round((Voz.JARVIS_PITCH - 0.5f) * 100));
            if (tts != null) {
                tts.setSpeechRate(Voz.JARVIS_RATE);
                tts.setPitch(Voz.JARVIS_PITCH);
                tts.speak("A sus órdenes, señor. Todos los sistemas en línea.", TextToSpeech.QUEUE_FLUSH, null, "prueba");
            }
            Toast.makeText(this, "Para que suene más a Jarvis, escoge también una voz de hombre.", Toast.LENGTH_LONG).show();
        });
        box.addView(jarvis);

        Button normal = new Button(this);
        normal.setAllCaps(false);
        normal.setText("Velocidad y tono normales");
        normal.setOnClickListener(v -> { rate.setProgress(50); pitch.setProgress(50); });
        box.addView(normal);

        final CheckBox quiet = new CheckBox(this);
        quiet.setText("Quitar el pitido del modo escucha");
        quiet.setChecked(p.getBoolean("quiet", true));
        box.addView(quiet);

        final CheckBox offline = new CheckBox(this);
        offline.setText("Escuchar sin internet (sin pitido). Si Nio no te oye, desmárcalo.");
        offline.setChecked(p.getBoolean("offline", true));
        box.addView(offline);

        Button overlay = new Button(this);
        overlay.setAllCaps(false);
        overlay.setText(Settings.canDrawOverlays(this) ? "Permiso para segundo plano: listo"
                : "Dar permiso para abrir apps en segundo plano");
        overlay.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));
        box.addView(overlay);

        Button perms = new Button(this);
        perms.setAllCaps(false);
        perms.setText("Revisar permisos (micrófono, contactos, llamadas)");
        perms.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        box.addView(perms);

        Button forget = new Button(this);
        forget.setAllCaps(false);
        forget.setText("Borrar todo lo que Nio aprendió");
        forget.setOnClickListener(v -> {
            p.edit().remove("routines").remove("facts").apply();
            Toast.makeText(this, "Nio olvidó sus rutinas y recuerdos.", Toast.LENGTH_SHORT).show();
        });
        box.addView(forget);

        ScrollView sv = new ScrollView(this);
        sv.addView(box);

        new AlertDialog.Builder(this, dialogTheme())
                .setTitle("Ajustes de Nio")
                .setView(sv)
                .setPositiveButton("Guardar", (d, w) -> {
                    p.edit().putString("name", name.getText().toString().trim())
                            .putString("key", key.getText().toString().trim())
                            .putString("model", model.getText().toString().trim())
                            .putString("voice", chosen[0])
                            .putFloat("rate", 0.5f + rate.getProgress() / 100f)
                            .putFloat("pitch", 0.5f + pitch.getProgress() / 100f)
                            .putBoolean("quiet", quiet.isChecked())
                            .putBoolean("offline", offline.isChecked())
                            .apply();
                    if (NioService.running) {
                        // reinicia el modo escucha para aplicar los cambios
                        stopService(new Intent(this, NioService.class));
                        reactor.postDelayed(() -> {
                            startForegroundService(new Intent(this, NioService.class));
                            NioService.running = true;
                            refreshWakeBtn();
                        }, 800);
                    }
                    Voz.apply(this, tts);
                    Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", (d, w) -> Voz.apply(this, tts))
                .show();
    }

    private void pickVoice(final String[] chosen) {
        if (tts == null) return;
        final List<Voice> voices = Voz.spanish(tts);
        if (voices.isEmpty()) {
            Toast.makeText(this, "No encontré voces en español. Instala \"Servicios de voz de Google\" desde la Play Store.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[voices.size()];
        int sel = -1;
        for (int i = 0; i < voices.size(); i++) {
            names[i] = Voz.label(voices.get(i), i);
            if (voices.get(i).getName().equals(chosen[0])) sel = i;
        }
        new AlertDialog.Builder(this, dialogTheme())
                .setTitle("Toca una voz para oírla")
                .setSingleChoiceItems(names, sel, (d, which) -> {
                    Voice v = voices.get(which);
                    chosen[0] = v.getName();
                    try { tts.setVoice(v); } catch (Exception ignored) { }
                    tts.speak("Hola señor, así sonaría mi voz.", TextToSpeech.QUEUE_FLUSH, null, "prueba");
                })
                .setPositiveButton("Usar esta", null)
                .show();
    }

    @Override
    protected void onDestroy() {
        if (sr != null) sr.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
