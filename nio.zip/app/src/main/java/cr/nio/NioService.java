package cr.nio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Modo escucha: Nio queda atento en silencio. Cuando oye "Nio" aparece la bolita
 * de colores, conversa contigo y se quita sola cuando ya no le hablas.
 */
public class NioService extends Service implements Brain.Out {

    public static final String ACTION_STOP = "cr.nio.STOP";
    public static volatile boolean running = false;

    private static final String CH = "nio_escucha";
    private static final String[] WAKE = {"nio", "neo", "nyo", "nillo", "nio nio", "mio nio"};
    private static final String[] BYE = {"gracias", "eso es todo", "nada", "nada mas", "listo", "ya", "no gracias",
            "es todo", "ya esta", "adios", "chao", "hasta luego"};

    private final Handler h = new Handler(Looper.getMainLooper());
    private SpeechRecognizer sr;
    private TextToSpeech tts;
    private Brain brain;
    private AudioManager am;
    private WindowManager wm;
    private ReactorView bubble;
    private boolean bubbleShown = false;

    private boolean speaking = false, stopped = false, listening = false;
    private boolean awaiting = false;   // espera una orden sin necesidad de decir "Nio"
    private boolean session = false;    // conversación activa (bolita visible)
    private boolean endAfterSpeak = false;
    private boolean musicMuted = false, systemMuted = false;
    private int uid = 0;

    private final Runnable hideBubble = this::hideBubbleNow;

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH, "Nio escuchando", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent piOpen = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, NioService.class).setAction(ACTION_STOP);
        PendingIntent piStop = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Nio está escuchando")
                .setContentText("Di \"Nio\" y lo que necesites")
                .setContentIntent(piOpen)
                .addAction(new Notification.Action.Builder(null, "Detener", piStop).build())
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(7, n);
        }

        brain = new Brain(this, this);
        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("es", "CR"));
                if (r < 0) tts.setLanguage(new Locale("es"));
                Voz.apply(this, tts);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) { h.post(NioService.this::doneSpeaking); }
                    @Override public void onError(String id) { h.post(NioService.this::doneSpeaking); }
                });
            }
        });

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf();
            return;
        }
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(listener);
        h.postDelayed(this::listen, 600);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) stopSelf();
        return START_NOT_STICKY;
    }

    // ---------- silenciar el pitido ----------

    private boolean quietWanted() {
        SharedPreferences p = getSharedPreferences(Brain.PREFS, MODE_PRIVATE);
        return p.getBoolean("quiet", true);
    }

    private void adjust(int stream, boolean mute) {
        try { am.adjustStreamVolume(stream, mute ? AudioManager.ADJUST_MUTE : AudioManager.ADJUST_UNMUTE, 0); }
        catch (Exception ignored) { }
    }

    /** Antes de escuchar: silencia los sonidos por donde sale el pitido (si no hay música sonando). */
    private void muteForListening() {
        if (!quietWanted()) { unmuteAll(); return; }
        if (am.isMusicActive()) {
            if (musicMuted) { adjust(AudioManager.STREAM_MUSIC, false); musicMuted = false; }
        } else if (!musicMuted) {
            adjust(AudioManager.STREAM_MUSIC, true); musicMuted = true;
        }
        if (!systemMuted) { adjust(AudioManager.STREAM_SYSTEM, true); systemMuted = true; }
    }

    private void unmuteAll() {
        if (musicMuted) { adjust(AudioManager.STREAM_MUSIC, false); musicMuted = false; }
        if (systemMuted) { adjust(AudioManager.STREAM_SYSTEM, false); systemMuted = false; }
    }

    // ---------- escuchar ----------

    private void listen() {
        if (stopped || speaking || sr == null || listening) return;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CR");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        muteForListening();
        try {
            listening = true;
            sr.startListening(i);
        } catch (Exception e) {
            listening = false;
            h.postDelayed(this::listen, 1500);
        }
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle b) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float v) { }
        @Override public void onBufferReceived(byte[] b) { }
        @Override public void onEndOfSpeech() { }
        @Override public void onPartialResults(Bundle b) { }
        @Override public void onEvent(int t, Bundle b) { }

        @Override public void onError(int error) {
            listening = false;
            long wait = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1200
                    : error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ? 4000
                    : 250;
            if ((error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH) && awaiting) {
                // no le hablaste: termina la conversación y se quita la bolita
                awaiting = false;
                endSession();
            }
            h.postDelayed(NioService.this::listen, wait);
        }

        @Override public void onResults(Bundle b) {
            listening = false;
            ArrayList<String> res = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            process(res);
            h.postDelayed(NioService.this::listen, 300);
        }
    };

    private void process(ArrayList<String> res) {
        if (res == null || res.isEmpty()) return;
        if (awaiting) {
            awaiting = false;
            String n = Brain.norm(res.get(0));
            for (String w : WAKE) if (n.startsWith(w + " ")) { n = n.substring(w.length() + 1); break; }
            for (String bye : BYE) {
                if (n.equals(bye)) {
                    endAfterSpeak = true;
                    say("Para servirle.");
                    return;
                }
            }
            showBubble(ReactorView.THINK);
            brain.handle(n);
            return;
        }
        for (String r : res) {
            String n = " " + Brain.norm(r) + " ";
            for (String w : WAKE) {
                int i = n.indexOf(" " + w + " ");
                if (i >= 0) {
                    session = true;
                    String rest = n.substring(i + w.length() + 2).trim();
                    if (rest.isEmpty()) {
                        showBubble(ReactorView.LISTEN);
                        say("¿Sí, señor?");
                    } else {
                        showBubble(ReactorView.THINK);
                        brain.handle(rest);
                    }
                    return;
                }
            }
        }
    }

    private void doneSpeaking() {
        if (tts != null && tts.isSpeaking()) return;
        speaking = false;
        if (endAfterSpeak) {
            endAfterSpeak = false;
            awaiting = false;
            endSession();
        } else if (session) {
            // sigue la conversación: puedes contestarle sin decir "Nio"
            awaiting = true;
            showBubble(ReactorView.LISTEN);
        }
        h.postDelayed(this::listen, 250);
    }

    private void endSession() {
        session = false;
        h.removeCallbacks(hideBubble);
        h.postDelayed(hideBubble, 400);
    }

    // ---------- bolita flotante ----------

    private void showBubble(int state) {
        h.removeCallbacks(hideBubble);
        if (!Settings.canDrawOverlays(this)) return;
        if (bubble == null) {
            bubble = new ReactorView(this);
            bubble.setRainbow(true);
            bubble.setOnClickListener(v -> {
                awaiting = false;
                session = false;
                if (tts != null) tts.stop();
                speaking = false;
                hideBubbleNow();
                h.postDelayed(this::listen, 300);
            });
        }
        bubble.setState(state);
        if (!bubbleShown) {
            float d = getResources().getDisplayMetrics().density;
            int size = (int) (110 * d);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(size, size,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.END;
            lp.x = (int) (10 * d);
            lp.y = (int) (160 * d);
            try { wm.addView(bubble, lp); bubbleShown = true; } catch (Exception ignored) { }
        }
    }

    private void hideBubbleNow() {
        if (bubbleShown && bubble != null) {
            try { wm.removeView(bubble); } catch (Exception ignored) { }
        }
        bubbleShown = false;
    }

    // ---------- Brain.Out ----------

    @Override
    public void say(String text) {
        if (tts == null || text == null || text.isEmpty()) return;
        speaking = true;
        if (sr != null) { try { sr.cancel(); } catch (Exception ignored) { } }
        listening = false;
        unmuteAll();
        if (session) showBubble(ReactorView.SPEAK);
        Voz.apply(this, tts);
        int r = tts.speak(text, TextToSpeech.QUEUE_ADD, null, "nio" + (uid++));
        if (r != TextToSpeech.SUCCESS) doneSpeaking();
    }

    @Override public void log(String who, String text) { }

    @Override public void thinking(boolean on) {
        if (on && session) showBubble(ReactorView.THINK);
    }

    @Override public void stopListening() { stopSelf(); }

    @Override
    public void onDestroy() {
        running = false;
        stopped = true;
        h.removeCallbacksAndMessages(null);
        hideBubbleNow();
        unmuteAll();
        if (sr != null) { try { sr.destroy(); } catch (Exception ignored) { } }
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
