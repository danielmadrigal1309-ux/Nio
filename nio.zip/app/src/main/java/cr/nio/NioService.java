package cr.nio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.ArrayList;
import java.util.Locale;

/** Modo escucha: Nio queda atento en segundo plano y despierta cuando oye su nombre. */
public class NioService extends Service implements Brain.Out {

    public static final String ACTION_STOP = "cr.nio.STOP";
    public static volatile boolean running = false;

    private static final String CH = "nio_escucha";
    private static final String[] WAKE = {"nio", "neo", "nyo", "nillo", "nio nio"};

    private final Handler h = new Handler(Looper.getMainLooper());
    private SpeechRecognizer sr;
    private TextToSpeech tts;
    private Brain brain;
    private boolean speaking = false, stopped = false, awaiting = false, listening = false;
    private int uid = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH, "Nio escuchando", NotificationManager.IMPORTANCE_LOW));

        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent piOpen = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, NioService.class).setAction(ACTION_STOP);
        PendingIntent piStop = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Nio está escuchando")
                .setContentText("Di \"Nio\" y lo que necesites")
                .setContentIntent(piOpen)
                .addAction(new Notification.Action.Builder(null, "Detener", piStop).build())
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(7, n);
        }

        brain = new Brain(this, this);
        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("es", "CR"));
                if (r < 0) tts.setLanguage(new Locale("es"));
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) { h.post(NioService.this::doneSpeaking); }
                    @Override public void onError(String id) { h.post(NioService.this::doneSpeaking); }
                });
            }
        });

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf();
            return;
        }
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(listener);
        h.postDelayed(this::listen, 600);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void listen() {
        if (stopped || speaking || sr == null || listening) return;
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CR");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        try {
            listening = true;
            sr.startListening(i);
        } catch (Exception e) {
            listening = false;
            h.postDelayed(this::listen, 1500);
        }
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle b) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float v) { }
        @Override public void onBufferReceived(byte[] b) { }
        @Override public void onEndOfSpeech() { }
        @Override public void onPartialResults(Bundle b) { }
        @Override public void onEvent(int t, Bundle b) { }

        @Override public void onError(int error) {
            listening = false;
            long wait = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1200
                    : error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ? 4000
                    : 250;
            if (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH) {
                // si estaba esperando una orden y no dijo nada, vuelve a modo espera
                awaiting = false;
            }
            h.postDelayed(NioService.this::listen, wait);
        }

        @Override public void onResults(Bundle b) {
            listening = false;
            ArrayList<String> res = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            process(res);
            h.postDelayed(NioService.this::listen, 300);
        }
    };

    private void process(ArrayList<String> res) {
        if (res == null || res.isEmpty()) return;
        if (awaiting) {
            awaiting = false;
            brain.handle(res.get(0));
            return;
        }
        for (String r : res) {
            String n = " " + Brain.norm(r) + " ";
            for (String w : WAKE) {
                int i = n.indexOf(" " + w + " ");
                if (i >= 0) {
                    String rest = n.substring(i + w.length() + 2).trim();
                    if (rest.isEmpty()) {
                        awaiting = true;
                        say("¿Sí, señor?");
                    } else {
                        brain.handle(rest);
                    }
                    return;
                }
            }
        }
    }

    private void doneSpeaking() {
        if (tts != null && tts.isSpeaking()) return;
        speaking = false;
        h.postDelayed(this::listen, 250);
    }

    // ---------- Brain.Out ----------

    @Override
    public void say(String text) {
        if (tts == null || text == null || text.isEmpty()) return;
        speaking = true;
        if (sr != null) { try { sr.cancel(); } catch (Exception ignored) { } }
        listening = false;
        int r = tts.speak(text, TextToSpeech.QUEUE_ADD, null, "nio" + (uid++));
        if (r != TextToSpeech.SUCCESS) doneSpeaking();
    }

    @Override public void log(String who, String text) { }
    @Override public void thinking(boolean on) { }
    @Override public void stopListening() { stopSelf(); }

    @Override
    public void onDestroy() {
        running = false;
        stopped = true;
        h.removeCallbacksAndMessages(null);
        if (sr != null) { try { sr.destroy(); } catch (Exception ignored) { } }
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
