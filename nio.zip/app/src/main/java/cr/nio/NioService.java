package cr.nio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Modo escucha: Beto queda en reposo (dormido) y se despierta cuando oye "Oye Beto".
 * de colores, conversa contigo y se quita sola cuando ya no le hablas.
 */
public class NioService extends Service implements Brain.Out {

    public static final String ACTION_STOP = "cr.nio.STOP";
    public static volatile boolean running = false;
    /** Lo último que oyó o el último error, para mostrarlo en la pantalla de Nio. */
    public static volatile String debug = "";

    private static final String CH = "nio_escucha";
    private static final String[] WAKE = {"oye beto", "hey beto", "oiga beto", "beto", "veto", "betto", "bebeto", "berto"};
    /** true mientras la ventana de Beto está abierta (ahí no hace falta el perrito flotante). */
    public static volatile boolean appVisible = false;
    private static final String[] BYE = {"gracias", "eso es todo", "nada", "nada mas", "listo", "ya", "no gracias",
            "es todo", "ya esta", "adios", "chao", "hasta luego"};

    private final Handler h = new Handler(Looper.getMainLooper());
    private SpeechRecognizer sr;
    private TextToSpeech tts;
    private Brain brain;
    private AudioManager am;
    private WindowManager wm;
    private DogView dog;
    private boolean dogShown = false;
    private WindowManager.LayoutParams dogLp;
    private int dogState = DogView.SLEEP;

    private boolean speaking = false, stopped = false, listening = false;
    private boolean awaiting = false;   // espera una orden sin necesidad de decir "Nio"
    private boolean session = false;    // conversación activa (bolita visible)
    private boolean endAfterSpeak = false;
    private boolean musicMuted = false, systemMuted = false, notifMuted = false;
    private boolean onDevice = false;   // reconocimiento dentro del teléfono: no hace pitido
    private int onDeviceFails = 0;
    private int errorsInRow = 0;
    private long listenStarted = 0;
    private final Runnable watchdog = new Runnable() {
        @Override public void run() {
            if (stopped) return;
            long now = System.currentTimeMillis();
            if (listening && now - listenStarted > 15000) {
                // se trabó: reinicia
                try { sr.cancel(); } catch (Exception ignored) { }
                listening = false;
                debug = "Reiniciando el oído…";
            }
            if (!listening && !speaking) listen();
            h.postDelayed(this, 4000);
        }
    };
    private int uid = 0;

    private final Runnable hideBubble = this::hideBubbleNow;
    private final Runnable dogSync = new Runnable() {
        @Override public void run() {
            if (stopped) return;
            syncDog();
            h.postDelayed(this, 500);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH, "Beto escuchando", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent piOpen = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, NioService.class).setAction(ACTION_STOP);
        PendingIntent piStop = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Beto está en reposo")
                .setContentText("Di \"Oye Beto\" y lo que necesites")
                .setContentIntent(piOpen)
                .addAction(new Notification.Action.Builder(null, "Detener", piStop).build())
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(7, n);
        }

        brain = new Brain(this, this);
        tts = new TextToSpeech(this, st -> {
            if (st == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("es", "CR"));
                if (r < 0) tts.setLanguage(new Locale("es"));
                Voz.apply(this, tts);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) { h.post(NioService.this::doneSpeaking); }
                    @Override public void onError(String id) { h.post(NioService.this::doneSpeaking); }
                });
            }
        });

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf();
            return;
        }
        createRecognizer();
        h.postDelayed(this::listen, 600);
        h.postDelayed(watchdog, 5000);
        h.postDelayed(dogSync, 300);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) stopSelf();
        return START_NOT_STICKY;
    }

    // ---------- reconocedor ----------

    private void createRecognizer() {
        if (sr != null) { try { sr.destroy(); } catch (Exception ignored) { } sr = null; }
        boolean wantOffline = getSharedPreferences(Brain.PREFS, MODE_PRIVATE).getBoolean("offline", true);
        boolean tryOnDevice = wantOffline && Build.VERSION.SDK_INT >= 31 && onDeviceFails < 3;
        if (tryOnDevice) {
            try {
                if (SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                    sr = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
                    onDevice = true;
                }
            } catch (Exception e) { sr = null; }
        }
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            onDevice = false;
        }
        sr.setRecognitionListener(listener);
        debug = onDevice ? "Escuchando (sin internet, sin pitido)" : "Escuchando (con internet)";
    }

    private Intent recognizerIntent() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, onDevice ? "es-US" : "es-CR");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        return i;
    }

    // ---------- silenciar el pitido ----------

    private boolean quietWanted() {
        SharedPreferences p = getSharedPreferences(Brain.PREFS, MODE_PRIVATE);
        return p.getBoolean("quiet", true);
    }

    private void adjust(int stream, boolean mute) {
        try { am.adjustStreamVolume(stream, mute ? AudioManager.ADJUST_MUTE : AudioManager.ADJUST_UNMUTE, 0); }
        catch (Exception ignored) { }
    }

    /** Antes de escuchar: silencia los sonidos por donde sale el pitido (si no hay música sonando). */
    private void muteForListening() {
        if (!quietWanted()) { unmuteAll(); return; }
        if (am.isMusicActive()) {
            if (musicMuted) { adjust(AudioManager.STREAM_MUSIC, false); musicMuted = false; }
        } else if (!musicMuted) {
            adjust(AudioManager.STREAM_MUSIC, true); musicMuted = true;
        }
        if (!systemMuted) { adjust(AudioManager.STREAM_SYSTEM, true); systemMuted = true; }
        if (!onDevice && !notifMuted) { adjust(AudioManager.STREAM_NOTIFICATION, true); notifMuted = true; }
        if (onDevice && notifMuted) { adjust(AudioManager.STREAM_NOTIFICATION, false); notifMuted = false; }
    }

    private void unmuteAll() {
        if (musicMuted) { adjust(AudioManager.STREAM_MUSIC, false); musicMuted = false; }
        if (systemMuted) { adjust(AudioManager.STREAM_SYSTEM, false); systemMuted = false; }
        if (notifMuted) { adjust(AudioManager.STREAM_NOTIFICATION, false); notifMuted = false; }
    }

    // ---------- escuchar ----------

    private void listen() {
        if (stopped || speaking || sr == null || listening) return;
        Intent i = recognizerIntent();
        muteForListening();
        try {
            listening = true;
            listenStarted = System.currentTimeMillis();
            sr.startListening(i);
        } catch (Exception e) {
            listening = false;
            h.postDelayed(this::listen, 1500);
        }
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle b) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float v) { DogView.level = Math.max(0f, Math.min(1f, (v + 2f) / 12f)); }
        @Override public void onBufferReceived(byte[] b) { }
        @Override public void onEndOfSpeech() { }
        @Override public void onPartialResults(Bundle b) { }
        @Override public void onEvent(int t, Bundle b) { }

        @Override public void onError(int error) {
            listening = false;
            debug = errorText(error);
            boolean normal = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT;
            errorsInRow = normal ? 0 : errorsInRow + 1;
            if (onDevice && errorsInRow >= 6) {
                onDeviceFails = 3;
                errorsInRow = 0;
                h.post(NioService.this::createRecognizer);
                h.postDelayed(NioService.this::listen, 800);
                return;
            }
            // 12 = idioma no soportado, 13 = idioma no descargado, 5 = error del cliente
            if (onDevice && (error == 12 || error == 13 || error == SpeechRecognizer.ERROR_CLIENT
                    || error == SpeechRecognizer.ERROR_SERVER)) {
                if (error == 13 && Build.VERSION.SDK_INT >= 33) {
                    try { sr.triggerModelDownload(recognizerIntent()); } catch (Exception ignored) { }
                }
                onDeviceFails++;
                if (onDeviceFails >= 3) {
                    h.post(NioService.this::createRecognizer);   // usa el reconocedor normal
                }
                h.postDelayed(NioService.this::listen, 1500);
                return;
            }
            long wait = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1200
                    : error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ? 4000
                    : 250;
            if ((error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH) && awaiting) {
                // no le hablaste: termina la conversación y se quita la bolita
                awaiting = false;
                endSession();
            }
            h.postDelayed(NioService.this::listen, wait);
        }

        @Override public void onResults(Bundle b) {
            listening = false;
            if (onDevice) onDeviceFails = 0;
            errorsInRow = 0;
            ArrayList<String> res = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (res != null && !res.isEmpty()) debug = "Oí: \"" + res.get(0) + "\"";
            process(res);
            h.postDelayed(NioService.this::listen, 300);
        }
    };

    private String errorText(int e) {
        String modo = onDevice ? " (sin internet)" : " (con internet)";
        switch (e) {
            case SpeechRecognizer.ERROR_NO_MATCH: return "No entendí nada" + modo;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "En reposo… di \"Oye Beto\"" + modo;
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "Sin internet para escuchar";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "Falta el permiso de micrófono";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "El micrófono está ocupado";
            case 12: case 13: return "Falta el paquete de voz en español" + modo;
            default: return "Error " + e + modo;
        }
    }

    /** "Chao Beto", "ciérrate Beto"… */
    private static final String[] GOODBYE = {"chao beto", "chau beto", "adios beto", "cierrate beto", "cierra te beto",
            "cerrate beto", "duermete beto", "descansa beto", "hasta luego beto", "nos vemos beto", "bye beto", "apagate beto"};

    private boolean isGoodbye(String n) {
        String x = " " + n + " ";
        for (String g : GOODBYE) if (x.contains(" " + g + " ")) return true;
        return false;
    }

    private void process(ArrayList<String> res) {
        if (res == null || res.isEmpty()) return;
        for (String r : res) {
            if (isGoodbye(Brain.norm(r))) {
                awaiting = false;
                if (session || dogState != DogView.SLEEP) {
                    session = true;
                    endAfterSpeak = true;
                    say("Chao, aquí estoy cuando me ocupés.");
                }
                return;
            }
        }
        if (awaiting) {
            awaiting = false;
            String n = Brain.norm(res.get(0));
            for (String w : WAKE) if (n.startsWith(w + " ")) { n = n.substring(w.length() + 1); break; }
            boolean bye = n.startsWith("gracias") || n.startsWith("muchas gracias") || n.equals("chao") || n.equals("cierrate");
            for (String b : BYE) if (n.equals(b)) bye = true;
            if (bye) {
                endAfterSpeak = true;
                say("Con gusto. Aquí estoy cuando me ocupés.");
                return;
            }
            showBubble(DogView.THINK);
            String raw = res.get(0);
            brain.handle(Brain.norm(raw).equals(n) ? raw : n);
            return;
        }
        for (String r : res) {
            String n = " " + Brain.norm(r) + " ";
            for (String w : WAKE) {
                int i = n.indexOf(" " + w + " ");
                if (i >= 0) {
                    session = true;
                    String rest = n.substring(i + w.length() + 2).trim();
                    if (rest.isEmpty()) {
                        showBubble(DogView.LISTEN);
                        say("¿Sí? Dígame.");
                    } else {
                        showBubble(DogView.THINK);
                        brain.handle(rest);
                    }
                    return;
                }
            }
        }
    }

    private void doneSpeaking() {
        if (tts != null && tts.isSpeaking()) return;
        speaking = false;
        if (endAfterSpeak) {
            endAfterSpeak = false;
            awaiting = false;
            endSession();
        } else if (session) {
            // sigue la conversación: puedes contestarle sin decir "Oye Beto"
            awaiting = true;
            showBubble(DogView.LISTEN);
        }
        h.postDelayed(this::listen, 250);
    }

    private void endSession() {
        session = false;
        h.removeCallbacks(hideBubble);
        h.postDelayed(hideBubble, 400);
    }

    // ---------- Beto flotante ----------

    /** Cambia lo que está haciendo el perrito flotante. */
    private void showBubble(int state) {
        h.removeCallbacks(hideBubble);
        dogState = state;
        if (dog != null) dog.setState(state);
        syncDog();
    }

    /** Fin de la conversación: Beto se vuelve a dormir. */
    private void hideBubbleNow() {
        dogState = DogView.SLEEP;
        if (dog != null) dog.setState(DogView.SLEEP);
    }

    /** Muestra a Beto flotando cuando la app está cerrada; lo quita cuando la abres. */
    private void syncDog() {
        boolean want = Settings.canDrawOverlays(this) && !appVisible
                && getSharedPreferences(Brain.PREFS, MODE_PRIVATE).getBoolean("floating", true);
        if (want && !dogShown) addDog();
        else if (!want && dogShown) removeDog();
    }

    private void addDog() {
        float d = getResources().getDisplayMetrics().density;
        if (dog == null) {
            dog = new DogView(this);
            dog.setOnTouchListener(new android.view.View.OnTouchListener() {
                float sx, sy; int lx, ly; boolean moved;
                @Override public boolean onTouch(android.view.View v, android.view.MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case android.view.MotionEvent.ACTION_DOWN:
                            sx = e.getRawX(); sy = e.getRawY(); lx = dogLp.x; ly = dogLp.y; moved = false;
                            return true;
                        case android.view.MotionEvent.ACTION_MOVE:
                            float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                            if (Math.abs(dx) + Math.abs(dy) > 12 * d) moved = true;
                            if (moved) {
                                dogLp.x = lx + (int) dx;
                                dogLp.y = ly + (int) dy;
                                try { wm.updateViewLayout(dog, dogLp); } catch (Exception ignored) { }
                            }
                            return true;
                        case android.view.MotionEvent.ACTION_UP:
                            if (moved) {
                                getSharedPreferences(Brain.PREFS, MODE_PRIVATE).edit()
                                        .putInt("dogX", dogLp.x).putInt("dogY", dogLp.y).apply();
                            } else {
                                tapDog();
                            }
                            return true;
                    }
                    return false;
                }
            });
        }
        dog.setState(dogState);
        SharedPreferences p = getSharedPreferences(Brain.PREFS, MODE_PRIVATE);
        dogLp = new WindowManager.LayoutParams((int) (230 * d), (int) (80 * d),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        dogLp.gravity = Gravity.TOP | Gravity.START;
        dogLp.x = p.getInt("dogX", (int) ((getResources().getDisplayMetrics().widthPixels - 230 * d) / 2));
        dogLp.y = p.getInt("dogY", (int) (420 * d));
        try { wm.addView(dog, dogLp); dogShown = true; } catch (Exception ignored) { }
    }

    private void removeDog() {
        if (dog != null) { try { wm.removeView(dog); } catch (Exception ignored) { } }
        dogShown = false;
    }

    /** Tocar a Beto: si duerme, se despierta y te escucha; si está hablando, se calla y se duerme. */
    private void tapDog() {
        if (session) {
            awaiting = false;
            session = false;
            if (tts != null) tts.stop();
            speaking = false;
            hideBubbleNow();
            h.postDelayed(this::listen, 300);
        } else {
            session = true;
            showBubble(DogView.LISTEN);
            say("¿Sí? Dígame.");
        }
    }

    // ---------- Brain.Out ----------

    @Override
    public void say(String text) {
        if (tts == null || text == null || text.isEmpty()) return;
        speaking = true;
        if (sr != null) { try { sr.cancel(); } catch (Exception ignored) { } }
        listening = false;
        unmuteAll();
        if (session) showBubble(DogView.SPEAK);
        Voz.apply(this, tts);
        int r = tts.speak(text, TextToSpeech.QUEUE_ADD, null, "beto" + (uid++));
        if (r != TextToSpeech.SUCCESS) doneSpeaking();
    }

    @Override public void log(String who, String text) { }

    @Override public void thinking(boolean on) {
        if (on && session) showBubble(DogView.THINK);
    }

    @Override public void stopListening() { stopSelf(); }

    @Override public void clearChat() { }

    @Override
    public void onDestroy() {
        running = false;
        debug = "";
        stopped = true;
        h.removeCallbacksAndMessages(null);
        removeDog();
        unmuteAll();
        if (sr != null) { try { sr.destroy(); } catch (Exception ignored) { } }
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
