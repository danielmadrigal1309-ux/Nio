package cr.nio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** El núcleo animado de Nio: cambia de color y velocidad según lo que esté haciendo. */
public class ReactorView extends View {

    public static final int IDLE = 0, LISTEN = 1, THINK = 2, SPEAK = 3;

    private int state = IDLE;
    private float angle = 0f;
    private long t0 = System.currentTimeMillis();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final float dp;

    public ReactorView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
    }

    public void setState(int s) {
        state = s;
        invalidate();
    }

    public int getState() { return state; }

    private int color() {
        switch (state) {
            case LISTEN: return Color.parseColor("#7DF9FF");
            case THINK: return Color.parseColor("#F5B942");
            case SPEAK: return Color.parseColor("#38BDF8");
            default: return Color.parseColor("#22D3EE");
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        if (w < 10 || h < 10) { postInvalidateOnAnimation(); return; }
        float cx = w / 2f, cy = h / 2f;
        float R = Math.min(w, h) / 2f * 0.92f;
        float sec = (System.currentTimeMillis() - t0) / 1000f;
        float speed = state == THINK ? 6f : state == LISTEN ? 3f : state == SPEAK ? 2.2f : 0.8f;
        angle = (angle + speed) % 360f;
        float pulse = (float) (0.5 + 0.5 * Math.sin(sec * (state == IDLE ? 1.5 : 5.0)));
        int col = color();
        int a = Color.argb(255, Color.red(col), Color.green(col), Color.blue(col));

        // resplandor
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx, cy, R, new int[]{
                Color.argb((int) (90 + 60 * pulse), Color.red(col), Color.green(col), Color.blue(col)),
                Color.argb(25, Color.red(col), Color.green(col), Color.blue(col)),
                Color.TRANSPARENT}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, R, p);
        p.setShader(null);

        // anillo exterior
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2 * dp);
        p.setColor(Color.argb(160, Color.red(col), Color.green(col), Color.blue(col)));
        c.drawCircle(cx, cy, R * 0.86f, p);

        // arcos que giran
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(5 * dp);
        p.setColor(a);
        float r1 = R * 0.78f;
        r.set(cx - r1, cy - r1, cx + r1, cy + r1);
        for (int i = 0; i < 3; i++) c.drawArc(r, angle + i * 120, 70, false, p);

        p.setStrokeWidth(3 * dp);
        p.setColor(Color.argb(200, Color.red(col), Color.green(col), Color.blue(col)));
        float r2 = R * 0.64f;
        r.set(cx - r2, cy - r2, cx + r2, cy + r2);
        for (int i = 0; i < 4; i++) c.drawArc(r, -angle * 1.4f + i * 90, 50, false, p);

        // segmentos
        p.setStrokeCap(Paint.Cap.BUTT);
        p.setStrokeWidth(9 * dp);
        p.setColor(Color.argb(120, Color.red(col), Color.green(col), Color.blue(col)));
        float r3 = R * 0.48f;
        r.set(cx - r3, cy - r3, cx + r3, cy + r3);
        for (int i = 0; i < 12; i++) c.drawArc(r, i * 30 + angle * 0.3f, 20, false, p);

        // núcleo
        p.setStyle(Paint.Style.FILL);
        float core = R * (0.26f + 0.03f * pulse);
        p.setShader(new RadialGradient(cx, cy, core, new int[]{Color.WHITE, a,
                Color.argb(0, Color.red(col), Color.green(col), Color.blue(col))},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, core, p);
        p.setShader(null);

        // nombre
        p.setColor(Color.parseColor("#04141C"));
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(R * 0.13f);
        p.setFakeBoldText(true);
        c.drawText("NIO", cx, cy + R * 0.045f, p);
        p.setFakeBoldText(false);

        postInvalidateOnAnimation();
    }
}
