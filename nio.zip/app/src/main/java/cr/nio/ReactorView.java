package cr.nio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** El núcleo animado de Nio: cambia de color y velocidad según lo que esté haciendo. */
public class ReactorView extends View {

    public static final int IDLE = 0, LISTEN = 1, THINK = 2, SPEAK = 3;

    private int state = IDLE;
    private boolean rainbow = false;
    private int tint = Color.WHITE;
    private boolean darkUi = true;
    private float angle = 0f;
    private long t0 = System.currentTimeMillis();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final float dp;

    public ReactorView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
    }

    public void setState(int s) {
        state = s;
        invalidate();
    }

    public int getState() { return state; }

    /** Color base tomado del sistema del teléfono. */
    public void setTint(int c, boolean dark) { tint = c; darkUi = dark; invalidate(); }

    private static int mix(int a, int b, float t) {
        return Color.rgb((int) (Color.red(a) + (Color.red(b) - Color.red(a)) * t),
                (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * t),
                (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t));
    }

    /** Bolita flotante: va cambiando de colores. */
    public void setRainbow(boolean r) { rainbow = r; invalidate(); }

    private int color(float sec) {
        if (rainbow) {
            float speed = state == THINK ? 160f : state == SPEAK ? 110f : 70f;
            return Color.HSVToColor(new float[]{(sec * speed) % 360f, 0.55f, 1f});
        }
        float[] hsv = new float[3];
        Color.colorToHSV(tint, hsv);
        switch (state) {
            case LISTEN: return mix(tint, Color.WHITE, 0.35f);
            case THINK: hsv[0] = (hsv[0] + 45f) % 360f; hsv[1] = Math.max(hsv[1], 0.35f); return Color.HSVToColor(hsv);
            case SPEAK: return mix(tint, Color.WHITE, 0.15f);
            default: return tint;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        if (w < 10 || h < 10) { postInvalidateOnAnimation(); return; }
        float cx = w / 2f, cy = h / 2f;
        float R = Math.min(w, h) / 2f * 0.92f;
        float sec = (System.currentTimeMillis() - t0) / 1000f;
        float speed = state == THINK ? 6f : state == LISTEN ? 3f : state == SPEAK ? 2.2f : 0.8f;
        angle = (angle + speed) % 360f;
        float pulse = (float) (0.5 + 0.5 * Math.sin(sec * (state == IDLE ? 1.5 : 5.0)));
        int col = color(sec);
        int a = Color.argb(255, Color.red(col), Color.green(col), Color.blue(col));

        // resplandor
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx, cy, R, new int[]{
                Color.argb((int) (45 + 45 * pulse), Color.red(col), Color.green(col), Color.blue(col)),
                Color.argb(14, Color.red(col), Color.green(col), Color.blue(col)),
                Color.TRANSPARENT}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, R, p);
        p.setShader(null);

        // anillo exterior
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2 * dp);
        p.setColor(Color.argb(70, Color.red(col), Color.green(col), Color.blue(col)));
        c.drawCircle(cx, cy, R * 0.86f, p);

        // arcos que giran
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(5 * dp);
        p.setColor(Color.argb(200, Color.red(col), Color.green(col), Color.blue(col)));
        float r1 = R * 0.78f;
        r.set(cx - r1, cy - r1, cx + r1, cy + r1);
        for (int i = 0; i < 3; i++) c.drawArc(r, angle + i * 120, 70, false, p);

        p.setStrokeWidth(3 * dp);
        p.setColor(Color.argb(130, Color.red(col), Color.green(col), Color.blue(col)));
        float r2 = R * 0.64f;
        r.set(cx - r2, cy - r2, cx + r2, cy + r2);
        for (int i = 0; i < 4; i++) c.drawArc(r, -angle * 1.4f + i * 90, 50, false, p);

        // segmentos
        p.setStrokeCap(Paint.Cap.BUTT);
        p.setStrokeWidth(9 * dp);
        p.setColor(Color.argb(60, Color.red(col), Color.green(col), Color.blue(col)));
        float r3 = R * 0.48f;
        r.set(cx - r3, cy - r3, cx + r3, cy + r3);
        for (int i = 0; i < 12; i++) c.drawArc(r, i * 30 + angle * 0.3f, 20, false, p);

        // núcleo
        p.setStyle(Paint.Style.FILL);
        float core = R * (0.26f + 0.03f * pulse);
        p.setShader(new RadialGradient(cx, cy, core, new int[]{Color.argb(235, 255, 255, 255), Color.argb(150, Color.red(col), Color.green(col), Color.blue(col)),
                Color.argb(0, Color.red(col), Color.green(col), Color.blue(col))},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, core, p);
        p.setShader(null);

        // nombre
        p.setColor(Color.argb(170, 0, 0, 0));
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(R * 0.13f);
        p.setFakeBoldText(true);
        c.drawText("NIO", cx, cy + R * 0.045f, p);
        p.setFakeBoldText(false);

        postInvalidateOnAnimation();
    }
}
