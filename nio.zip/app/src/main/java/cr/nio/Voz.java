package cr.nio;

import android.content.Context;
import android.content.SharedPreferences;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Voz de Nio: cuál voz usar, qué tan rápido y qué tan grave. */
public class Voz {

    public static final float JARVIS_RATE = 0.92f;
    public static final float JARVIS_PITCH = 0.78f;

    private static String lastApplied = null;

    public static void apply(Context c, TextToSpeech tts) {
        if (tts == null) return;
        SharedPreferences p = c.getSharedPreferences(Brain.PREFS, Context.MODE_PRIVATE);
        String name = p.getString("voice", "");
        try {
            if (!name.isEmpty()) {
                Voice cur = tts.getVoice();
                if (cur == null || !name.equals(cur.getName()) || !name.equals(lastApplied)) {
                    Set<Voice> vs = tts.getVoices();
                    if (vs != null) {
                        for (Voice v : vs) {
                            if (v.getName().equals(name)) { tts.setVoice(v); lastApplied = name; break; }
                        }
                    }
                }
            }
        } catch (Exception ignored) { }
        tts.setSpeechRate(p.getFloat("rate", 1f));
        tts.setPitch(p.getFloat("pitch", 1f));
    }

    /** Voces en español instaladas en el teléfono. */
    public static List<Voice> spanish(TextToSpeech tts) {
        List<Voice> out = new ArrayList<>();
        try {
            Set<Voice> vs = tts.getVoices();
            if (vs != null) {
                for (Voice v : vs) {
                    Locale l = v.getLocale();
                    if (l == null || !"es".equals(l.getLanguage())) continue;
                    Set<String> f = v.getFeatures();
                    if (f != null && f.contains("notInstalled")) continue;
                    out.add(v);
                }
            }
        } catch (Exception ignored) { }
        Collections.sort(out, (a, b) -> {
            int x = a.getLocale().toString().compareTo(b.getLocale().toString());
            return x != 0 ? x : a.getName().compareTo(b.getName());
        });
        return out;
    }

    public static String label(Voice v, int i) {
        Locale l = v.getLocale();
        String country = l.getDisplayCountry(new Locale("es"));
        if (country.isEmpty()) country = "Español";
        return "Voz " + (i + 1) + " · " + country + (v.isNetworkConnectionRequired() ? " (usa internet)" : "");
    }
}
