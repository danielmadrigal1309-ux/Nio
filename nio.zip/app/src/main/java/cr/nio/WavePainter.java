package cr.nio;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;

/**
 * La "línea de frecuencia" de Beto: casi quieta en reposo, se ondula con tu voz cuando escucha
 * y salta al ritmo cuando Beto habla.
 */
public class WavePainter {

    public static final int SLEEP = -1, IDLE = 0, LISTEN = 1, THINK = 2, SPEAK = 3;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private float amp = 0.02f;      // amplitud suavizada
    private float lvl = 0f;         // nivel de voz suavizado

    // tres ondas: color, frecuencia, velocidad, fase
    private static final int[] COLORS = {Color.rgb(125, 227, 244), Color.rgb(167, 139, 250), Color.rgb(244, 114, 182)};
    private static final float[] FREQ = {1.6f, 2.3f, 1.15f};
    private static final float[] SPEED = {2.4f, -3.1f, 1.7f};
    private static final float[] PHASE = {0f, 1.7f, 3.4f};
    private static final float[] WEIGHT = {1f, 0.75f, 0.6f};

    /** level: volumen de la voz de 0 a 1 (cuando escucha). */
    public void draw(Canvas c, float w, float h, int state, float t, float level) {
        lvl += (level - lvl) * 0.25f;
        float target;
        switch (state) {
            case SLEEP: target = 0.025f + 0.012f * (float) Math.sin(t * 1.4); break;
            case LISTEN: target = 0.10f + lvl * 0.32f; break;
            case THINK: target = 0.09f; break;
            case SPEAK:
                float env = Math.abs((float) (Math.sin(t * 7.3) * Math.sin(t * 2.1 + 0.6)))
                        + 0.35f * Math.abs((float) Math.sin(t * 13.7));
                target = 0.10f + 0.30f * Math.min(1f, env);
                break;
            default: target = 0.05f + 0.015f * (float) Math.sin(t * 2.0);
        }
        amp += (target - amp) * (state == SPEAK ? 0.35f : 0.12f);

        float cy = h / 2f;
        float pad = w * 0.04f;
        float span = w - 2 * pad;
        float stroke = Math.max(2f, h * 0.035f);
        int alphaMain = state == SLEEP ? 120 : 220;
        float speedMul = state == SLEEP ? 0.35f : state == THINK ? 2.2f : state == SPEAK ? 1.6f : 1f;

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);

        // línea base tenue
        p.setShader(new LinearGradient(pad, 0, w - pad, 0,
                new int[]{Color.argb(0, 255, 255, 255), Color.argb(state == SLEEP ? 110 : 70, 255, 255, 255), Color.argb(0, 255, 255, 255)},
                null, Shader.TileMode.CLAMP));
        p.setStrokeWidth(stroke * 0.5f);
        c.drawLine(pad, cy, w - pad, cy, p);
        p.setShader(null);

        for (int k = COLORS.length - 1; k >= 0; k--) {
            float a = amp * h * WEIGHT[k];
            path.reset();
            int steps = 90;
            for (int i = 0; i <= steps; i++) {
                float x = i / (float) steps;
                // se afina en las puntas (forma de huso)
                float taper = (float) Math.pow(Math.sin(Math.PI * x), 2.2);
                // en "pensando" una onda viaja de lado a lado
                float pulse = 1f;
                if (state == THINK) {
                    float center = (float) ((Math.sin(t * 1.8) + 1) / 2);
                    pulse = 0.25f + 1.1f * (float) Math.exp(-Math.pow((x - center) * 4.5, 2));
                }
                float y = cy + a * taper * pulse
                        * (float) Math.sin(2 * Math.PI * FREQ[k] * x + PHASE[k] + t * SPEED[k] * speedMul);
                float px = pad + x * span;
                if (i == 0) path.moveTo(px, y); else path.lineTo(px, y);
            }
            int col = COLORS[k];
            // resplandor
            int ga = (int) (alphaMain * 0.22f);
            p.setShader(new LinearGradient(pad, 0, w - pad, 0,
                    new int[]{Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                            Color.argb(ga, Color.red(col), Color.green(col), Color.blue(col)),
                            Color.argb(0, Color.red(col), Color.green(col), Color.blue(col))},
                    null, Shader.TileMode.CLAMP));
            p.setStrokeWidth(stroke * 3.2f);
            c.drawPath(path, p);
            p.setShader(null);
            // línea
            p.setShader(new LinearGradient(pad, 0, w - pad, 0,
                    new int[]{Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                            Color.argb(alphaMain, Color.red(col), Color.green(col), Color.blue(col)),
                            Color.argb(0, Color.red(col), Color.green(col), Color.blue(col))},
                    null, Shader.TileMode.CLAMP));
            p.setStrokeWidth(stroke);
            c.drawPath(path, p);
            p.setShader(null);
        }
        // núcleo blanco brillante
        path.reset();
        for (int i = 0; i <= 90; i++) {
            float x = i / 90f;
            float taper = (float) Math.pow(Math.sin(Math.PI * x), 2.2);
            float y = cy + amp * h * 0.55f * taper * (float) Math.sin(2 * Math.PI * 1.9f * x + t * 2.8f * speedMul);
            float px = pad + x * span;
            if (i == 0) path.moveTo(px, y); else path.lineTo(px, y);
        }
        p.setShader(new LinearGradient(pad, 0, w - pad, 0,
                new int[]{Color.argb(0, 255, 255, 255), Color.argb(state == SLEEP ? 140 : 235, 255, 255, 255), Color.argb(0, 255, 255, 255)},
                null, Shader.TileMode.CLAMP));
        p.setStrokeWidth(stroke * 0.6f);
        c.drawPath(path, p);
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
    }
}
